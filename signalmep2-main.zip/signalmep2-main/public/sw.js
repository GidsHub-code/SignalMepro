// SignalMe service worker — push + notification click handling
self.addEventListener("install", (e) => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));

self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { title: "SignalMe", body: event.data ? event.data.text() : "" };
  }
  const title = data.title || "SignalMe";
  const tag = data.tag || (data.url || "signalme");
  const options = {
    body: data.body || "",
    icon: "/icon-192.png",
    badge: "/icon-192.png",
    tag,
    renotify: true,
    requireInteraction: true,
    vibrate: [200, 100, 200, 100, 200],
    silent: false,
    data: { url: data.url || "/" },
  };

  event.waitUntil(
    (async () => {
      // Show notification (interrupts even when tab is closed)
      await self.registration.showNotification(title, options);

      // Update app badge count from total open notifications
      try {
        if (self.navigator && "setAppBadge" in self.navigator) {
          const all = await self.registration.getNotifications();
          await self.navigator.setAppBadge(all.length);
        }
      } catch {}

      // Tell any open client to refresh unread state
      try {
        const clients = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
        clients.forEach((c) => c.postMessage({ type: "push", url: options.data.url }));
      } catch {}
    })()
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = event.notification.data?.url || "/";
  event.waitUntil(
    (async () => {
      try {
        if (self.navigator && "clearAppBadge" in self.navigator) {
          await self.navigator.clearAppBadge();
        }
      } catch {}
      const clientList = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      for (const client of clientList) {
        if ("focus" in client) {
          try { await client.navigate(url); } catch {}
          return client.focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
    })()
  );
});
