import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react";
import { useLocation } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";

type Counts = Record<string, number>;

type Ctx = {
  counts: Counts;
  total: number;
  markRead: (conversationId: string) => void;
};

const UnreadCtx = createContext<Ctx | null>(null);

const READ_KEY = (uid: string) => `chat-read:${uid}`;

function loadReadMap(uid: string): Record<string, string> {
  try {
    return JSON.parse(localStorage.getItem(READ_KEY(uid)) || "{}");
  } catch {
    return {};
  }
}

function saveReadMap(uid: string, map: Record<string, string>) {
  try {
    localStorage.setItem(READ_KEY(uid), JSON.stringify(map));
  } catch {}
}

function setBadge(n: number) {
  try {
    const nav: any = navigator;
    if (n > 0) nav.setAppBadge?.(n);
    else nav.clearAppBadge?.();
  } catch {}
}

export function UnreadChatsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const loc = useLocation();
  const [counts, setCounts] = useState<Counts>({});

  const recompute = useCallback(async (uid: string) => {
    const readMap = loadReadMap(uid);
    const { data: convs } = await supabase
      .from("conversations")
      .select("id")
      .or(`client_id.eq.${uid},agent_id.eq.${uid}`);
    const ids = (convs as { id: string }[] | null)?.map((c) => c.id) ?? [];
    if (ids.length === 0) {
      setCounts({});
      setBadge(0);
      return;
    }
    const next: Counts = {};
    await Promise.all(
      ids.map(async (cid) => {
        const since = readMap[cid] || "1970-01-01T00:00:00Z";
        const { count } = await supabase
          .from("messages")
          .select("*", { count: "exact", head: true })
          .eq("conversation_id", cid)
          .neq("sender_id", uid)
          .gt("created_at", since);
        if (count && count > 0) next[cid] = count;
      })
    );
    setCounts(next);
    setBadge(Object.values(next).reduce((a, b) => a + b, 0));
  }, []);

  const markRead = useCallback(
    (conversationId: string) => {
      if (!user) return;
      const map = loadReadMap(user.id);
      map[conversationId] = new Date().toISOString();
      saveReadMap(user.id, map);
      setCounts((prev) => {
        const next = { ...prev };
        delete next[conversationId];
        setBadge(Object.values(next).reduce((a, b) => a + b, 0));
        return next;
      });
    },
    [user]
  );

  // Auto-mark current conversation as read when path matches
  useEffect(() => {
    const m = loc.pathname.match(/^\/chats\/([^/]+)$/);
    if (m && user) markRead(m[1]);
  }, [loc.pathname, user, markRead]);

  useEffect(() => {
    if (!user) {
      setCounts({});
      setBadge(0);
      return;
    }
    recompute(user.id);

    const ch = supabase
      .channel(`unread-${user.id}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages" },
        async (payload) => {
          const m = payload.new as { sender_id: string; conversation_id: string };
          if (m.sender_id === user.id) return;
          // Verify the user is part of the conversation
          const { data: conv } = await supabase
            .from("conversations")
            .select("client_id, agent_id")
            .eq("id", m.conversation_id)
            .maybeSingle();
          if (!conv || (conv.client_id !== user.id && conv.agent_id !== user.id)) return;
          // Skip if user is currently viewing that chat
          if (window.location.pathname === `/chats/${m.conversation_id}`) {
            markRead(m.conversation_id);
            return;
          }
          setCounts((prev) => {
            const next = { ...prev, [m.conversation_id]: (prev[m.conversation_id] || 0) + 1 };
            setBadge(Object.values(next).reduce((a, b) => a + b, 0));
            return next;
          });
        }
      )
      .subscribe();

    const onVisible = () => {
      if (!document.hidden) recompute(user.id);
    };
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      supabase.removeChannel(ch);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [user, recompute, markRead]);

  const total = Object.values(counts).reduce((a, b) => a + b, 0);

  return <UnreadCtx.Provider value={{ counts, total, markRead }}>{children}</UnreadCtx.Provider>;
}

export function useUnreadChats() {
  const ctx = useContext(UnreadCtx);
  if (!ctx) return { counts: {} as Counts, total: 0, markRead: (_: string) => {} };
  return ctx;
}
