// Native push registration (Capacitor + FCM/APNs).
// On web this is a no-op; the existing Web Push flow (src/lib/push.ts) is used.
// On android/ios this registers with the OS, receives the device token, and
// stores it in the `push_subscriptions` table with platform metadata.

import { supabase } from "@/integrations/supabase/client";

export type NativePlatform = "web" | "android";

export function getNativePlatform(): NativePlatform {
  if (typeof window === "undefined") return "web";
  // Lazy access — Capacitor global is injected by the native shell only.
  const cap = (window as any).Capacitor;
  if (!cap || typeof cap.getPlatform !== "function") return "web";
  // iOS support intentionally deferred — native runs are Android-only for now.
  return cap.getPlatform() === "android" ? "android" : "web";
}

export function isNative(): boolean {
  return getNativePlatform() !== "web";
}

let registered = false;

export async function registerNativePushForCurrentUser(userId: string): Promise<void> {
  if (registered) return;
  const platform = getNativePlatform();
  if (platform === "web") return;

  // Dynamic import so the web bundle never tries to resolve native plugins.
  const [{ PushNotifications }, { App }] = await Promise.all([
    import("@capacitor/push-notifications"),
    import("@capacitor/app"),
  ]);

  // Permissions
  let perm = await PushNotifications.checkPermissions();
  if (perm.receive === "prompt" || perm.receive === "prompt-with-rationale") {
    perm = await PushNotifications.requestPermissions();
  }
  if (perm.receive !== "granted") return;

  // OS registration
  await PushNotifications.register();

  PushNotifications.addListener("registration", async (token) => {
    const deviceToken = token.value;
    if (!deviceToken) return;
    try {
      await supabase
        .from("push_subscriptions")
        .upsert(
          {
            user_id: userId,
            platform,
            device_token: deviceToken,
            // Web columns left null for native rows
            endpoint: deviceToken,
            p256dh: "",
            auth: "",
          },
          { onConflict: "endpoint" },
        );
    } catch {
      // swallow — best-effort
    }
  });

  PushNotifications.addListener("registrationError", () => {
    // No-op; user simply won't receive native pushes.
  });

  // Tap → deep link
  PushNotifications.addListener("pushNotificationActionPerformed", (event) => {
    const link = (event.notification?.data as any)?.link as string | undefined;
    if (link && typeof window !== "undefined") {
      window.location.assign(link);
    }
  });

  // App opened from a custom URL (universal link / scheme)
  App.addListener("appUrlOpen", (data) => {
    try {
      const url = new URL(data.url);
      if (url.pathname && typeof window !== "undefined") {
        window.location.assign(url.pathname + url.search);
      }
    } catch {
      // ignore non-URL payloads
    }
  });

  registered = true;
}
