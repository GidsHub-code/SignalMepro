export const NIGERIA_STATES = [
  "Abia","Adamawa","Akwa Ibom","Anambra","Bauchi","Bayelsa","Benue","Borno","Cross River","Delta",
  "Ebonyi","Edo","Ekiti","Enugu","FCT - Abuja","Gombe","Imo","Jigawa","Kaduna","Kano","Katsina",
  "Kebbi","Kogi","Kwara","Lagos","Nasarawa","Niger","Ogun","Ondo","Osun","Oyo","Plateau","Rivers",
  "Sokoto","Taraba","Yobe","Zamfara",
] as const;

export const PROPERTY_TYPES = [
  { value: "shop", label: "Shop" },
  { value: "office", label: "Office" },
  { value: "hall", label: "Hall" },
  { value: "duplex", label: "Duplex" },
  { value: "warehouse", label: "Warehouse" },
  { value: "1_room", label: "1 Room" },
  { value: "1_room_selfcon", label: "1 Room Self-Contained" },
  { value: "room_and_parlour", label: "Room and Parlour" },
  { value: "2_bed_flat", label: "2-Bedroom Flat" },
  { value: "3_bed_flat", label: "3-Bedroom Flat" },
] as const;

export type PropertyType = typeof PROPERTY_TYPES[number]["value"];

export const propertyLabel = (v: string) =>
  PROPERTY_TYPES.find((p) => p.value === v)?.label ?? v;

export const formatNaira = (n: number) =>
  "₦" + n.toLocaleString("en-NG");
