// Plain constants and helpers used by the subscribe page.
// Auth-bound DB work is done with the browser supabase client; the
// Flutterwave secret-key verify lives at /api/payments/verify-flutterwave.

export const PRO_PRICE_NAIRA = 5500;

export const FLUTTERWAVE_PUBLIC_KEY =
  (import.meta as any).env?.VITE_FLUTTERWAVE_PUBLIC_KEY ?? "";
