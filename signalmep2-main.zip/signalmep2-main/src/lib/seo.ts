// SEO helper: builds consistent meta tags + JSON-LD for SignalMe routes.
// Targeting Nigerian real-estate rental queries (rent, lease, agent search,
// houses, apartments, shops, shortlets) — competing with Jiji & PropertyPro.

const SITE_URL = "https://signalme.app";
const SITE_NAME = "SignalMe";
const DEFAULT_OG =
  "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/95a74530-42ce-4ac7-80ca-9d5f4481c9fe/id-preview-59a640d8--526b7c15-93d9-4b79-84f3-efc60eaa4179.lovable.app-1777919328192.png";

export type SeoInput = {
  title: string;
  description: string;
  path: string; // e.g. "/about"
  keywords?: string;
  image?: string;
  jsonLd?: object | object[];
  noindex?: boolean;
};

export function buildHead(input: SeoInput) {
  const url = `${SITE_URL}${input.path === "/" ? "" : input.path}`;
  const image = input.image || DEFAULT_OG;
  const meta: Array<Record<string, string>> = [
    { title: input.title },
    { name: "description", content: input.description },
    {
      name: "keywords",
      content:
        input.keywords ||
        "houses for rent in Nigeria, apartments for rent, real estate Nigeria, property rental Lagos, Abuja apartments, verified real estate agents Nigeria, shortlet, self-contain, mini flat, 2 bedroom flat, shop for rent, office space, Jiji houses, PropertyPro alternative",
    },
    { name: "robots", content: input.noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large" },
    { name: "author", content: SITE_NAME },
    { property: "og:type", content: "website" },
    { property: "og:site_name", content: SITE_NAME },
    { property: "og:url", content: url },
    { property: "og:title", content: input.title },
    { property: "og:description", content: input.description },
    { property: "og:image", content: image },
    { property: "og:locale", content: "en_NG" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "twitter:title", content: input.title },
    { name: "twitter:description", content: input.description },
    { name: "twitter:image", content: image },
    { name: "geo.region", content: "NG" },
    { name: "geo.placename", content: "Nigeria" },
  ];

  const links = [{ rel: "canonical", href: url }];

  const jsonLdScripts = input.jsonLd
    ? (Array.isArray(input.jsonLd) ? input.jsonLd : [input.jsonLd]).map((j) => ({
        type: "application/ld+json" as const,
        children: JSON.stringify(j),
      }))
    : [];

  return { meta, links, scripts: jsonLdScripts };
}

export const ORG_JSON_LD = {
  "@context": "https://schema.org",
  "@type": "RealEstateAgent",
  name: SITE_NAME,
  url: SITE_URL,
  logo: `${SITE_URL}/icon-512.png`,
  image: DEFAULT_OG,
  description:
    "Nigeria's demand-first real estate platform. Renters post what they need, verified agents respond instantly with matching houses, flats, shortlets, shops and offices across Lagos, Abuja, Port Harcourt and beyond.",
  areaServed: {
    "@type": "Country",
    name: "Nigeria",
  },
  sameAs: [],
};

export const WEBSITE_JSON_LD = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: SITE_NAME,
  url: SITE_URL,
  potentialAction: {
    "@type": "SearchAction",
    target: `${SITE_URL}/request?q={search_term_string}`,
    "query-input": "required name=search_term_string",
  },
};

export function faqJsonLd(items: { q: string; a: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: items.map((i) => ({
      "@type": "Question",
      name: i.q,
      acceptedAnswer: { "@type": "Answer", text: i.a },
    })),
  };
}

export function breadcrumbJsonLd(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: `${SITE_URL}${it.path === "/" ? "" : it.path}`,
    })),
  };
}
