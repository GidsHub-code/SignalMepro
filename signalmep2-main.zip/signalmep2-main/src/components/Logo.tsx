import logo from "@/assets/signalme-logo.jpeg";

export function Logo({ className = "h-7 w-7" }: { className?: string }) {
  return (
    <img
      src={logo}
      alt="SignalMe"
      className={`${className} rounded-full object-cover`}
      loading="eager"
    />
  );
}
