import { useEffect, useRef } from "react";
import { useRouter, useLocation } from "@tanstack/react-router";
import { toast } from "sonner";
import { Radar, MessageSquare } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { registerPushForCurrentUser } from "@/lib/push";

// Short beep generated via WebAudio (no asset required)
function playBeep() {
  try {
    const Ctx = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(880, ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.18);
    g.gain.setValueAtTime(0.0001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
    o.connect(g);
    g.connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + 0.4);
    setTimeout(() => ctx.close().catch(() => {}), 600);
  } catch {}
}

function isPreviewOrIframe() {
  try {
    if (window.self !== window.top) return true;
  } catch {
    return true;
  }
  const h = window.location.hostname;
  return h.includes("id-preview--") || h.includes("lovableproject.com");
}

async function ensureSwAndPermission() {
  if (isPreviewOrIframe()) return;
  if ("serviceWorker" in navigator) {
    try {
      await navigator.serviceWorker.register("/sw.js");
    } catch {}
  }
  if ("Notification" in window && Notification.permission === "default") {
    try {
      await Notification.requestPermission();
    } catch {}
  }
}

async function showSystemNotification(title: string, body: string, url?: string) {
  if (!("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  try {
    const reg = "serviceWorker" in navigator ? await navigator.serviceWorker.getRegistration() : null;
    const opts: NotificationOptions = {
      body,
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      tag: "signalme",
      renotify: true,
      data: { url: url || "/" },
    } as any;
    if (reg) {
      await reg.showNotification(title, opts);
    } else {
      new Notification(title, opts);
    }
  } catch {}
}

export function NotificationListener() {
  const { user } = useAuth();
  const router = useRouter();
  const loc = useLocation();
  const pathRef = useRef(loc.pathname);
  pathRef.current = loc.pathname;

  useEffect(() => {
    if (!user) return;
    ensureSwAndPermission().then(() => registerPushForCurrentUser(user.id).catch(() => {}));
    // Native (Capacitor) registration — no-op on web
    import("@/lib/native-push").then(({ registerNativePushForCurrentUser }) =>
      registerNativePushForCurrentUser(user.id).catch(() => {}),
    );

    const notifChannel = supabase
      .channel(`notif-${user.id}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
        (payload) => {
          const n = payload.new as { title: string; body: string; link: string | null };
          playBeep();
          toast(n.title, {
            description: n.body,
            icon: <Radar className="h-4 w-4 text-primary" />,
            action: n.link
              ? { label: "View", onClick: () => router.navigate({ to: n.link as any }) }
              : undefined,
          });
          if (document.hidden) showSystemNotification(n.title, n.body, n.link || "/");
        }
      )
      .subscribe();

    const msgChannel = supabase
      .channel(`msg-${user.id}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages" },
        async (payload) => {
          const m = payload.new as { sender_id: string; conversation_id: string; body: string; media_type: string | null };
          if (m.sender_id === user.id) return;
          const { data: conv } = await supabase
            .from("conversations")
            .select("client_id, agent_id")
            .eq("id", m.conversation_id)
            .maybeSingle();
          if (!conv || (conv.client_id !== user.id && conv.agent_id !== user.id)) return;
          if (pathRef.current === `/chats/${m.conversation_id}`) return;

          const preview = m.body
            ? m.body
            : m.media_type === "image"
              ? "📷 Photo"
              : m.media_type === "video"
                ? "🎥 Video"
                : m.media_type === "audio"
                  ? "🎙️ Voice note"
                  : "New message";
          playBeep();
          toast("New message", {
            description: preview,
            icon: <MessageSquare className="h-4 w-4 text-primary" />,
            action: {
              label: "Open",
              onClick: () => router.navigate({ to: "/chats/$id", params: { id: m.conversation_id } }),
            },
          });
          if (document.hidden) {
            showSystemNotification("New message", preview, `/chats/${m.conversation_id}`);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(notifChannel);
      supabase.removeChannel(msgChannel);
    };
  }, [user, router]);

  return null;
}
