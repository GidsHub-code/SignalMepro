import { createFileRoute, useNavigate, redirect, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { Eye, EyeOff } from "lucide-react";
import { Logo } from "@/components/Logo";

const search = z.object({
  role: z.enum(["client", "agent"]).optional().default("client"),
  plan: z.enum(["free", "trial", "pro"]).optional(),
  redirect: z.string().optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: (s) => search.parse(s),
  beforeLoad: async ({ search }) => {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();

    if (!error && user) {
      const { data: prof } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .maybeSingle();

      const finalRole = prof?.role ?? search.role;
      if (finalRole === "agent" && (search.plan === "pro" || search.plan === "trial")) {
        throw redirect({ to: "/subscribe", search: { autostart: search.plan } as any });
      }

      throw redirect({ to: finalRole === "agent" ? "/agent" : "/client" });
    }
  },
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { role: initialRole, plan } = Route.useSearch();
  // If the user arrived from /plans (plan param present) default to signup;
  // otherwise default to signin (returning user just clicking "Sign in").
  const [mode, setMode] = useState<"signin" | "signup">(plan ? "signup" : "signin");
  const [role, setRole] = useState<"client" | "agent">(initialRole);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);

  const routeAfterAuth = async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    const { data: prof } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", u.user.id)
      .maybeSingle();
    const finalRole = prof?.role ?? role;

    if (finalRole === "agent" && plan === "pro") {
      navigate({ to: "/subscribe", search: { autostart: "pro" } as any });
      return;
    }

    if (finalRole === "agent" && plan === "trial") {
      navigate({ to: "/subscribe", search: { autostart: "trial" } as any });
      return;
    }

    navigate({ to: finalRole === "agent" ? "/agent" : "/client" });
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/`,
            data: { full_name: fullName, phone, role },
          },
        });
        if (error) {
          if (/already|registered|exists/i.test(error.message)) {
            throw new Error("This email is already registered. Please sign in instead.");
          }
          throw error;
        }
        if (data.user && data.user.identities && data.user.identities.length === 0) {
          throw new Error("This email is already registered. Please sign in instead.");
        }
        toast.success("Account created — welcome to SignalMe!");
        const { error: signErr } = await supabase.auth.signInWithPassword({ email, password });
        if (signErr) {
          setMode("signin");
          return;
        }
        await routeAfterAuth();
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Signed in");
        await routeAfterAuth();
      }
    } catch (err: any) {
      toast.error(err.message ?? "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-5 py-10 bg-secondary/40">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-2 justify-center font-bold text-xl mb-6">
          <Logo className="h-10 w-10" />
          SignalMe
        </div>
        <div className="rounded-2xl bg-card border shadow-sm p-6">
          {plan && mode === "signup" && (
            <div className="mb-4 rounded-lg border border-primary/30 bg-primary/5 px-3 py-2 text-sm">
              Selected plan:{" "}
              <strong>
                {plan === "free" ? "Renter (Free)" : plan === "trial" ? "Agent — Free Trial" : "Agent Pro"}
              </strong>
              .{" "}
              <Link to="/plans" className="underline">Change</Link>
            </div>
          )}
          <Tabs value={mode} onValueChange={(v) => setMode(v as any)}>
            <TabsList className="grid grid-cols-2 w-full">
              <TabsTrigger value="signup">Sign up</TabsTrigger>
              <TabsTrigger value="signin">Sign in</TabsTrigger>
            </TabsList>
            <TabsContent value="signup" />
            <TabsContent value="signin" />
          </Tabs>

          <form onSubmit={submit} className="space-y-4 mt-4">
            {mode === "signup" && (
              <>
                <div>
                  <Label className="mb-2 block">I am a…</Label>
                  <RadioGroup value={role} onValueChange={(v) => setRole(v as any)} className="grid grid-cols-2 gap-2">
                    <label className={`border rounded-lg p-3 cursor-pointer flex items-center gap-2 ${role === "client" ? "border-primary bg-primary/5" : ""}`}>
                      <RadioGroupItem value="client" /> Renter
                    </label>
                    <label className={`border rounded-lg p-3 cursor-pointer flex items-center gap-2 ${role === "agent" ? "border-primary bg-primary/5" : ""}`}>
                      <RadioGroupItem value="agent" /> Agent
                    </label>
                  </RadioGroup>
                </div>
                <div>
                  <Label htmlFor="name">Full name</Label>
                  <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
                </div>
                <div>
                  <Label htmlFor="phone">Phone number</Label>
                  <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+234..." required />
                </div>
              </>
            )}
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div>
              <Label htmlFor="pw">Password</Label>
              <div className="relative">
                <Input
                  id="pw"
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength={6}
                  required
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((s) => !s)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-muted-foreground hover:text-foreground"
                  aria-label={showPw ? "Hide password" : "Show password"}
                  tabIndex={-1}
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" disabled={loading} className="w-full" size="lg">
              {loading ? "Please wait…" : mode === "signup" ? "Create account" : "Sign in"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
