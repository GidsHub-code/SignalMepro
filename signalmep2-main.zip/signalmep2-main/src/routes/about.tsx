import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead, ORG_JSON_LD, breadcrumbJsonLd } from "@/lib/seo";

export const Route = createFileRoute("/about")({
  head: () =>
    buildHead({
      title: "About SignalMe — Nigeria's Demand-First Real Estate Platform",
      description:
        "Learn how SignalMe is changing house rental in Nigeria. Renters post what they want — verified real estate agents in Lagos, Abuja, Port Harcourt and across Nigeria respond instantly with matching apartments, flats, shortlets, shops and offices.",
      path: "/about",
      keywords:
        "about SignalMe, Nigerian real estate platform, rent house Nigeria, find verified agent Lagos, Abuja property platform, alternative to Jiji houses, alternative to PropertyPro, property rental marketplace Nigeria",
      jsonLd: [ORG_JSON_LD, breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "About", path: "/about" }])],
    }),
  component: About,
});

function About() {
  return (
    <main className="max-w-3xl mx-auto px-5 py-12">
      <Link to="/" className="text-primary text-sm">← Home</Link>
      <h1 className="text-3xl font-bold mt-4 mb-6">About SignalMe</h1>
      <p className="text-base leading-relaxed">SignalMe is Nigeria's demand-first rental platform. Instead of scrolling through endless listings, renters post exactly what they want — type, area, budget — and verified agents in that area receive a Signal instantly.</p>
      <p className="text-base leading-relaxed mt-4">Our mission is to remove scams, save time, and put renters back in control. SignalMe is built and operated by Gidsworld Ventures.</p>
      <h2 className="text-xl font-semibold mt-8 mb-2">Why we exist</h2>
      <p>Nigerians waste days chasing agents. We flip that — agents chase verified demand. Everyone wins.</p>
      <h2 className="text-xl font-semibold mt-8 mb-2">Contact</h2>
      <p>Email: support@signalmepro.lovable.app</p>
    </main>
  );
}
