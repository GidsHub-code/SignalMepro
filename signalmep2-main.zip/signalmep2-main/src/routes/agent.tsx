import { createFileRoute, Link, redirect, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Radar, Search, MessageSquare, Settings, ArrowRight, Sparkles, Crown } from "lucide-react";

export const Route = createFileRoute("/agent")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  component: AgentHome,
});

function AgentHome() {
  const { profile, user } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState({ matched: 0, unread: 0, chats: 0 });
  const [hasCoverage, setHasCoverage] = useState(true);

  useEffect(() => {
    if (profile && profile.role !== "agent") router.navigate({ to: "/client" });
  }, [profile]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: p } = await supabase.from("agent_preferences").select("*").eq("agent_id", user.id).maybeSingle();
      setHasCoverage(!!(p && p.states?.length && p.property_types?.length));

      const { count: unread } = await supabase
        .from("notifications").select("*", { count: "exact", head: true })
        .eq("user_id", user.id).eq("read", false);

      const { count: chats } = await supabase
        .from("conversations").select("*", { count: "exact", head: true }).eq("agent_id", user.id);

      let matched = 0;
      if (p && p.states?.length && p.property_types?.length) {
        const { data } = await supabase.from("requests").select("id,area")
          .eq("status", "open")
          .in("state", p.states)
          .in("property_type", p.property_types as any)
          .gte("max_budget", p.min_budget)
          .lte("min_budget", p.max_budget);
        let rows = data ?? [];
        if (p.areas?.length) rows = rows.filter((r: any) => p.areas!.includes(r.area));
        matched = rows.length;
      }
      setStats({ matched, unread: unread ?? 0, chats: chats ?? 0 });
    })();
  }, [user]);

  return (
    <AppShell>
      <section className="rounded-2xl p-6 text-primary-foreground shadow-lg" style={{ background: "var(--gradient-primary)" }}>
        <div className="flex items-center gap-2 text-xs uppercase tracking-wider opacity-80">
          <Radar className="h-3.5 w-3.5" /> Agent hub
        </div>
        <h1 className="text-2xl font-bold mt-1">Hi {profile?.full_name?.split(" ")[0] || "agent"} 👋</h1>
        <p className="text-sm opacity-90 mt-1">
          Your Signal Matrix is scanning new requests for matches in your coverage area.
        </p>
        <Button asChild variant="secondary" className="mt-4 gap-1">
          <Link to="/signals">
            <Radar className="h-4 w-4" /> Open Signal Matrix
          </Link>
        </Button>
      </section>

      <div className="grid grid-cols-3 gap-3 mt-5">
        <StatCard label="Matched" value={stats.matched} />
        <StatCard label="Unread" value={stats.unread} />
        <StatCard label="Chats" value={stats.chats} />
      </div>

      {!hasCoverage && (
        <div className="rounded-2xl border-l-4 border-l-accent bg-accent/10 p-4 mt-5">
          <strong>Set your coverage</strong>
          <p className="text-sm mt-1">Add the states, areas, property types and budgets you handle to start receiving signals.</p>
          <Button asChild size="sm" className="mt-2"><Link to="/profile">Set up Signal Matrix</Link></Button>
        </div>
      )}

      <h2 className="font-semibold mt-6 mb-3">Quick actions</h2>
      <div className="space-y-3">
        <ActionCard to="/signals" icon={Radar} title="Signal Matrix" desc="Live matches based on your coverage" />
        <ActionCard to="/signals" search={{ tab: "search" }} icon={Search} title="Search requests" desc="Browse all open requests with filters" />
        <ActionCard to="/chats" icon={MessageSquare} title="Messages" desc="Conversations with renters" />
        <ActionCard to="/subscribe" icon={Crown} title="Agent Pro subscription" desc="1 month free trial or ₦5,500/mo via Flutterwave" />
        <ActionCard to="/profile" icon={Settings} title="Coverage settings" desc="States, areas, property types and budget" />
      </div>

      <div className="rounded-2xl border-l-4 border-l-primary bg-primary/5 p-4 mt-6 flex gap-3">
        <Sparkles className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
        <div className="text-sm">
          <strong>Tip</strong>
          <p className="text-muted-foreground mt-1">
            Reply within minutes — early responders close more deals on SignalMe.
          </p>
        </div>
      </div>
    </AppShell>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border bg-card p-4 text-center">
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}

function ActionCard({ to, search, icon: Icon, title, desc }: { to: string; search?: any; icon: any; title: string; desc: string }) {
  return (
    <Link to={to as any} search={search} className="flex items-center gap-3 rounded-2xl border bg-card p-4 hover:border-primary transition-colors">
      <span className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
        <Icon className="h-5 w-5" />
      </span>
      <div className="flex-1 min-w-0">
        <div className="font-medium">{title}</div>
        <div className="text-xs text-muted-foreground truncate">{desc}</div>
      </div>
      <ArrowRight className="h-4 w-4 text-muted-foreground" />
    </Link>
  );
}
