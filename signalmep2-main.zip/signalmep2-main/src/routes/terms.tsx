import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo";

export const Route = createFileRoute("/terms")({
  head: () =>
    buildHead({
      title: "Terms of Service — SignalMe",
      description:
        "The terms and conditions governing your use of SignalMe — Nigeria's demand-first real estate rental platform.",
      path: "/terms",
    }),
  component: Terms,
});

function Terms() {
  return (
    <main className="max-w-3xl mx-auto px-5 py-12">
      <Link to="/" className="text-primary text-sm">← Home</Link>
      <h1 className="text-3xl font-bold mt-4 mb-6">Terms of Service</h1>
      <p className="text-sm text-muted-foreground">Last updated: May 2026</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">Acceptance</h2>
      <p>By using SignalMe you agree to these terms. If you don't agree, do not use the service.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">Use of the service</h2>
      <p>You must be at least 18 to use SignalMe. You agree not to post fraudulent listings, spam other users, or attempt to bypass platform safety measures.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">No payments through SignalMe</h2>
      <p>SignalMe does not handle property payments. Never pay for a property you have not physically inspected. SignalMe is not liable for transactions made off-platform.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">Termination</h2>
      <p>We may suspend or terminate accounts that violate these terms.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">Contact</h2>
      <p>Email: support@signalmepro.lovable.app</p>
    </main>
  );
}
