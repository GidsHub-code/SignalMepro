import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/push/vapid-public-key")({
  server: {
    handlers: {
      GET: async () => {
        const key = process.env.VAPID_PUBLIC_KEY;
        if (!key) {
          return new Response(
            JSON.stringify({ error: "VAPID_PUBLIC_KEY not configured" }),
            { status: 500, headers: { "Content-Type": "application/json" } },
          );
        }
        return new Response(JSON.stringify({ key }), {
          status: 200,
          headers: {
            "Content-Type": "application/json",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
