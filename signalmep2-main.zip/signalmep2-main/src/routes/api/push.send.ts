import { createFileRoute } from "@tanstack/react-router";
import webpush from "web-push";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const VAPID_PUBLIC = "BGcvdePXzLQP0YVzX2tbIiwFd-HW7bDL0Om05cEg32JQwjBSqRyRD2ejC1cFbX_RNkilbSVDq5djULRGH43nO8E";

function configure() {
  const priv = process.env.VAPID_PRIVATE_KEY;
  const pub = process.env.VAPID_PUBLIC_KEY || VAPID_PUBLIC;
  if (!priv) throw new Error("VAPID_PRIVATE_KEY not configured");
  webpush.setVapidDetails("mailto:support@signalme.app", pub, priv);
}

export const Route = createFileRoute("/api/push/send")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          configure();
        } catch (e: any) {
          return new Response(e.message, { status: 500 });
        }
        const authHeader = request.headers.get("authorization") || "";
        const token = authHeader.replace(/^Bearer\s+/i, "");
        if (!token) return new Response("Unauthorized", { status: 401 });
        const { data: userData, error: authErr } = await supabaseAdmin.auth.getUser(token);
        if (authErr || !userData.user) return new Response("Unauthorized", { status: 401 });

        const body = await request.json().catch(() => null);
        if (!body || !body.user_id || !body.title) {
          return new Response("Bad request", { status: 400 });
        }
        const { user_id, title, message, url } = body as {
          user_id: string;
          title: string;
          message?: string;
          url?: string;
        };

        const { data: subs } = await supabaseAdmin
          .from("push_subscriptions")
          .select("*")
          .eq("user_id", user_id);

        if (!subs || subs.length === 0) {
          return Response.json({ sent: 0 });
        }

        const payload = JSON.stringify({
          title,
          body: message || "",
          url: url || "/",
        });

        let sent = 0;
        await Promise.all(
          subs.map(async (s: any) => {
            try {
              await webpush.sendNotification(
                {
                  endpoint: s.endpoint,
                  keys: { p256dh: s.p256dh, auth: s.auth },
                },
                payload,
              );
              sent++;
            } catch (err: any) {
              if (err?.statusCode === 404 || err?.statusCode === 410) {
                await supabaseAdmin
                  .from("push_subscriptions")
                  .delete()
                  .eq("endpoint", s.endpoint);
              }
            }
          }),
        );

        return Response.json({ sent });
      },
    },
  },
});
