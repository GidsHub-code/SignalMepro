import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/payments/flutterwave-config")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const publicKey = process.env.FLUTTERWAVE_PUBLIC_KEY ?? "";
          if (!publicKey) {
            console.warn(
              "[flutterwave-config] FLUTTERWAVE_PUBLIC_KEY not set in server env",
            );
          } else {
            console.log("[flutterwave-config] returning public key (len)", publicKey.length);
          }
          return Response.json({ publicKey });
        } catch (e: any) {
          console.error("[flutterwave-config] error", e);
          return Response.json(
            { publicKey: "", error: e?.message || "config error" },
            { status: 200 },
          );
        }
      },
    },
  },
});
