import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { PRO_PRICE_NAIRA } from "@/lib/subscription.functions";

function jsonError(message: string, status: number, extra?: Record<string, unknown>) {
  return Response.json({ ok: false, error: message, ...(extra || {}) }, { status });
}

export const Route = createFileRoute("/api/payments/verify-flutterwave")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          // 1. Auth
          const authHeader = request.headers.get("authorization") || "";
          const token = authHeader.replace(/^Bearer\s+/i, "");
          if (!token) {
            console.warn("[verify-flutterwave] missing bearer token");
            return jsonError("Unauthorized", 401);
          }

          let userId: string;
          try {
            const { data: userData, error: authErr } =
              await supabaseAdmin.auth.getUser(token);
            if (authErr || !userData?.user) {
              console.warn("[verify-flutterwave] auth.getUser failed", authErr?.message);
              return jsonError("Unauthorized", 401);
            }
            userId = userData.user.id;
            console.log("[verify-flutterwave] authenticated user", userId);
          } catch (e: any) {
            console.error("[verify-flutterwave] supabase auth threw", e);
            return jsonError("Auth verification failed", 500);
          }

          // 2. Body
          const body = await request.json().catch(() => null);
          if (!body?.transaction_id || !body?.tx_ref) {
            console.warn("[verify-flutterwave] bad body", body);
            return jsonError("Missing transaction_id or tx_ref", 400);
          }

          // 3. Env
          const secret = process.env.FLUTTERWAVE_SECRET_KEY;
          if (!secret) {
            console.error("[verify-flutterwave] FLUTTERWAVE_SECRET_KEY not configured");
            return jsonError("Payment gateway not configured", 500);
          }

          // 4. Verify with Flutterwave
          let tx: any;
          try {
            const res = await fetch(
              `https://api.flutterwave.com/v3/transactions/${encodeURIComponent(
                String(body.transaction_id),
              )}/verify`,
              { headers: { Authorization: `Bearer ${secret}` } },
            );
            const json: any = await res.json().catch(() => ({}));
            console.log("[verify-flutterwave] FW response", {
              ok: res.ok,
              status: json?.status,
              tx_status: json?.data?.status,
              amount: json?.data?.amount,
              currency: json?.data?.currency,
            });
            if (!res.ok || json.status !== "success") {
              return jsonError(json?.message || "Verification failed", 400);
            }
            tx = json.data;
          } catch (e: any) {
            console.error("[verify-flutterwave] fetch failed", e);
            return jsonError("Could not reach payment gateway", 502);
          }

          if (
            tx.status !== "successful" ||
            tx.tx_ref !== body.tx_ref ||
            tx.currency !== "NGN" ||
            Number(tx.amount) < PRO_PRICE_NAIRA
          ) {
            console.warn("[verify-flutterwave] tx mismatch", {
              tx_status: tx.status,
              tx_ref: tx.tx_ref,
              expected_ref: body.tx_ref,
              currency: tx.currency,
              amount: tx.amount,
            });
            return jsonError("Payment did not match expected amount/status", 400);
          }

          // 5. Update subscription
          const periodEnd = new Date();
          periodEnd.setDate(periodEnd.getDate() + 30);

          try {
            const { data: existing, error: selErr } = await supabaseAdmin
              .from("subscriptions")
              .select("id")
              .eq("user_id", userId)
              .maybeSingle();

            if (selErr) {
              console.error("[verify-flutterwave] sub select error", selErr);
              return jsonError("Could not load subscription", 500);
            }

            if (existing) {
              const { error } = await supabaseAdmin
                .from("subscriptions")
                .update({
                  plan: "pro",
                  status: "active",
                  current_period_end: periodEnd.toISOString(),
                  last_tx_ref: body.tx_ref,
                  last_tx_id: String(body.transaction_id),
                  amount_naira: Number(tx.amount),
                  updated_at: new Date().toISOString(),
                })
                .eq("user_id", userId);
              if (error) {
                console.error("[verify-flutterwave] sub update error", error);
                return jsonError(error.message, 500);
              }
              console.log("[verify-flutterwave] subscription updated for", userId);
            } else {
              const { error } = await supabaseAdmin.from("subscriptions").insert({
                user_id: userId,
                plan: "pro",
                status: "active",
                current_period_end: periodEnd.toISOString(),
                last_tx_ref: body.tx_ref,
                last_tx_id: String(body.transaction_id),
                amount_naira: Number(tx.amount),
              });
              if (error) {
                console.error("[verify-flutterwave] sub insert error", error);
                return jsonError(error.message, 500);
              }
              console.log("[verify-flutterwave] subscription created for", userId);
            }
          } catch (e: any) {
            console.error("[verify-flutterwave] sub write threw", e);
            return jsonError("Could not save subscription", 500);
          }

          return Response.json({
            ok: true,
            periodEnd: periodEnd.toISOString(),
          });
        } catch (e: any) {
          console.error("[verify-flutterwave] unhandled", e);
          return jsonError(e?.message || "Internal error", 500);
        }
      },
    },
  },
});
