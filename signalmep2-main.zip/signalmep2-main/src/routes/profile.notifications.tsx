import { createFileRoute, redirect, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Bell, BellOff, Smartphone, Trash2, ArrowLeft, CheckCircle2, AlertTriangle, Download } from "lucide-react";
import { toast } from "sonner";
import { registerPushForCurrentUser } from "@/lib/push";
import { buildHead } from "@/lib/seo";

export const Route = createFileRoute("/profile/notifications")({
  head: () =>
    buildHead({
      title: "Notification Settings — SignalMe",
      description: "Manage push notifications and subscribed devices for your SignalMe account.",
      path: "/profile/notifications",
      noindex: true,
    }),
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  component: NotificationsSettings,
});

type Device = {
  id: string;
  endpoint: string;
  created_at: string;
};

function detectBrowser(endpoint: string) {
  if (endpoint.includes("fcm.googleapis.com") || endpoint.includes("android.googleapis.com"))
    return "Chrome / Android";
  if (endpoint.includes("mozilla.com") || endpoint.includes("autopush")) return "Firefox";
  if (endpoint.includes("windows.com") || endpoint.includes("notify.windows")) return "Edge / Windows";
  if (endpoint.includes("push.apple.com") || endpoint.includes("web.push.apple"))
    return "Safari / iOS";
  return "Browser";
}

function NotificationsSettings() {
  const { user } = useAuth();
  const [devices, setDevices] = useState<Device[]>([]);
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const [pushSupported, setPushSupported] = useState(false);
  const [swActive, setSwActive] = useState(false);
  const [pwaInstalled, setPwaInstalled] = useState(false);
  const [currentEndpoint, setCurrentEndpoint] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from("push_subscriptions")
      .select("id, endpoint, created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setDevices((data as Device[]) || []);

    if ("serviceWorker" in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      setSwActive(!!reg?.active);
      const sub = await reg?.pushManager.getSubscription();
      setCurrentEndpoint(sub?.endpoint || null);
    }
  }, [user]);

  useEffect(() => {
    setPushSupported(
      typeof window !== "undefined" &&
        "serviceWorker" in navigator &&
        "PushManager" in window &&
        "Notification" in window,
    );
    if ("Notification" in window) setPermission(Notification.permission);
    const standalone =
      window.matchMedia?.("(display-mode: standalone)").matches ||
      // @ts-expect-error iOS only
      window.navigator.standalone === true;
    setPwaInstalled(!!standalone);
    refresh();
  }, [refresh]);

  const enablePush = async () => {
    if (!user) return;
    setBusy(true);
    try {
      await registerPushForCurrentUser(user.id);
      setPermission(Notification.permission);
      await refresh();
      if (Notification.permission === "granted") {
        toast.success("Push notifications enabled on this device");
      } else {
        toast.error("Permission denied. Enable notifications in your browser settings.");
      }
    } finally {
      setBusy(false);
    }
  };

  const disableThisDevice = async () => {
    setBusy(true);
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      const sub = await reg?.pushManager.getSubscription();
      if (sub) {
        await supabase.from("push_subscriptions").delete().eq("endpoint", sub.endpoint);
        await sub.unsubscribe();
      }
      await refresh();
      toast.success("Push disabled on this device");
    } finally {
      setBusy(false);
    }
  };

  const removeDevice = async (id: string, endpoint: string) => {
    await supabase.from("push_subscriptions").delete().eq("id", id);
    if (endpoint === currentEndpoint) {
      const reg = await navigator.serviceWorker.getRegistration();
      const sub = await reg?.pushManager.getSubscription();
      await sub?.unsubscribe();
    }
    await refresh();
    toast.success("Device removed");
  };

  const sendTest = async () => {
    if (!user) return;
    setBusy(true);
    try {
      const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-push`;
      const res = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({
          user_id: user.id,
          title: "SignalMe test",
          body: "If you see this, push is working 🎉",
          url: "/profile/notifications",
        }),
      });
      const json = await res.json();
      if (json?.sent > 0) toast.success(`Test sent to ${json.sent} device(s)`);
      else toast.error("No subscribed devices received it. Try enabling first.");
    } catch {
      toast.error("Failed to send test notification");
    } finally {
      setBusy(false);
    }
  };

  const isEnabledHere = permission === "granted" && !!currentEndpoint;

  return (
    <AppShell>
      <div className="space-y-5">
        <div className="flex items-center gap-2">
          <Link to="/profile" className="p-2 -ml-2 rounded-md hover:bg-muted">
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <h1 className="text-2xl font-bold">Notifications</h1>
        </div>

        {/* Master toggle */}
        <div className="rounded-xl border bg-card p-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 font-semibold">
                {isEnabledHere ? <Bell className="h-4 w-4 text-primary" /> : <BellOff className="h-4 w-4" />}
                Push notifications on this device
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Get instant alerts for new chat messages and matching property requests, even when the app is closed.
              </p>
            </div>
            <Switch
              checked={isEnabledHere}
              disabled={busy || !pushSupported}
              onCheckedChange={(v) => (v ? enablePush() : disableThisDevice())}
            />
          </div>

          {!pushSupported && (
            <div className="mt-4 flex items-start gap-2 text-sm text-amber-600">
              <AlertTriangle className="h-4 w-4 mt-0.5" />
              <span>Your browser does not support push notifications.</span>
            </div>
          )}
          {pushSupported && permission === "denied" && (
            <div className="mt-4 flex items-start gap-2 text-sm text-amber-600">
              <AlertTriangle className="h-4 w-4 mt-0.5" />
              <span>
                Notifications are blocked. Allow them in your browser's site settings, then reload.
              </span>
            </div>
          )}

          <div className="mt-4">
            <Button variant="outline" size="sm" onClick={sendTest} disabled={busy || !isEnabledHere}>
              Send test notification
            </Button>
          </div>
        </div>

        {/* PWA status */}
        <div className="rounded-xl border bg-card p-5">
          <div className="font-semibold flex items-center gap-2">
            <Smartphone className="h-4 w-4 text-primary" /> App install (PWA)
          </div>
          <div className="mt-3 grid gap-2 text-sm">
            <Row label="Installed to home screen" ok={pwaInstalled} />
            <Row label="Service worker active" ok={swActive} />
            <Row label="Push API supported" ok={pushSupported} />
            <Row label="Notification permission granted" ok={permission === "granted"} />
          </div>
          {!pwaInstalled && (
            <p className="text-xs text-muted-foreground mt-3 flex items-start gap-1.5">
              <Download className="h-3.5 w-3.5 mt-0.5" />
              On iPhone: tap Share → "Add to Home Screen". On Android Chrome: tap menu → "Install app".
              Push notifications work best when SignalMe is installed.
            </p>
          )}
        </div>

        {/* Devices */}
        <div className="rounded-xl border bg-card p-5">
          <div className="font-semibold mb-3">Subscribed devices ({devices.length})</div>
          {devices.length === 0 ? (
            <p className="text-sm text-muted-foreground">No devices yet. Enable push above to subscribe this device.</p>
          ) : (
            <ul className="divide-y">
              {devices.map((d) => {
                const isThis = d.endpoint === currentEndpoint;
                return (
                  <li key={d.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-medium text-sm flex items-center gap-2">
                        {detectBrowser(d.endpoint)}
                        {isThis && <Badge variant="secondary" className="text-[10px]">This device</Badge>}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Added {new Date(d.created_at).toLocaleDateString()}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeDevice(d.id, d.endpoint)}
                      className="text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </AppShell>
  );
}

function Row({ label, ok }: { label: string; ok: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      {ok ? (
        <span className="inline-flex items-center gap-1 text-emerald-600">
          <CheckCircle2 className="h-4 w-4" /> Yes
        </span>
      ) : (
        <span className="inline-flex items-center gap-1 text-muted-foreground">
          <AlertTriangle className="h-4 w-4" /> No
        </span>
      )}
    </div>
  );
}
