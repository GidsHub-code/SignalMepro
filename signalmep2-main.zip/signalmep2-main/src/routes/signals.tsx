import { createFileRoute, Link, redirect, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { NIGERIA_STATES, PROPERTY_TYPES, formatNaira, propertyLabel } from "@/lib/constants";
import { MapPin, Phone, MessageCircle, Radar, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

const searchSchema = z.object({
  tab: z.enum(["matched", "search"]).optional().default("matched"),
});

export const Route = createFileRoute("/signals")({
  validateSearch: (s) => searchSchema.parse(s),
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  component: AgentSignalsPage,
});

type Req = {
  id: string;
  client_id: string;
  property_type: string;
  state: string;
  area: string;
  min_budget: number;
  max_budget: number;
  phone: string;
  description: string;
  status: string;
  created_at: string;
};

function AgentSignalsPage() {
  const { profile, user } = useAuth();
  const router = useRouter();
  const { tab: initialTab } = Route.useSearch();
  const [tab, setTab] = useState<string>(initialTab);
  const [matched, setMatched] = useState<Req[]>([]);
  const [search, setSearch] = useState<Req[]>([]);

  const [fState, setFState] = useState("");
  const [fArea, setFArea] = useState("");
  const [fType, setFType] = useState("");
  const [fMin, setFMin] = useState("");
  const [fMax, setFMax] = useState("");

  useEffect(() => {
    if (profile && profile.role !== "agent") router.navigate({ to: "/client" });
  }, [profile]);

  const loadMatched = async () => {
    if (!user) return;
    const { data: p } = await supabase.from("agent_preferences").select("*").eq("agent_id", user.id).maybeSingle();
    if (!p || !p.states?.length || !p.property_types?.length) {
      setMatched([]);
      return;
    }
    const { data } = await supabase.from("requests").select("*").eq("status", "open")
      .in("state", p.states)
      .in("property_type", p.property_types as any)
      .gte("max_budget", p.min_budget)
      .lte("min_budget", p.max_budget)
      .order("created_at", { ascending: false });
    let rows = (data as Req[]) ?? [];
    if (p.areas?.length) rows = rows.filter((r) => p.areas!.includes(r.area));
    setMatched(rows);
  };

  const runSearch = async () => {
    let q = supabase.from("requests").select("*").eq("status", "open").order("created_at", { ascending: false }).limit(50);
    if (fState) q = q.eq("state", fState);
    if (fArea) q = q.ilike("area", `%${fArea}%`);
    if (fType) q = q.eq("property_type", fType as any);
    if (fMin) q = q.gte("max_budget", Number(fMin));
    if (fMax) q = q.lte("min_budget", Number(fMax));
    const { data } = await q;
    setSearch((data as Req[]) ?? []);
  };

  useEffect(() => { loadMatched(); runSearch(); /* eslint-disable-next-line */ }, [user]);

  useEffect(() => {
    if (!user) return;
    const ch = supabase.channel("requests-feed")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "requests" }, () => loadMatched())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line
  }, [user]);

  const startChat = async (r: Req) => {
    if (!user) return;
    const { data: existing } = await supabase
      .from("conversations").select("id")
      .eq("request_id", r.id).eq("agent_id", user.id).maybeSingle();
    let convId = existing?.id;
    if (!convId) {
      const { data, error } = await supabase.from("conversations")
        .insert({ request_id: r.id, agent_id: user.id, client_id: r.client_id })
        .select("id").single();
      if (error) { toast.error(error.message); return; }
      convId = data.id;
    }
    router.navigate({ to: "/chats/$id", params: { id: convId! } });
  };

  return (
    <AppShell>
      <div className="flex items-center gap-2 mb-4">
        <Link to="/agent"><Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button></Link>
        <div>
          <h1 className="text-2xl font-bold leading-tight">Signal Matrix</h1>
          <p className="text-sm text-muted-foreground">Live request matches & search</p>
        </div>
      </div>
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid grid-cols-2 w-full">
          <TabsTrigger value="matched" className="gap-1"><Radar className="h-4 w-4" /> Matched</TabsTrigger>
          <TabsTrigger value="search">Search</TabsTrigger>
        </TabsList>

        <TabsContent value="matched" className="mt-4 space-y-3">
          {matched.length === 0 ? (
            <Empty text="No matches yet. We'll signal you instantly when one comes in." />
          ) : matched.map((r) => <RequestCard key={r.id} r={r} onChat={() => startChat(r)} />)}
        </TabsContent>

        <TabsContent value="search" className="mt-4">
          <div className="rounded-2xl bg-card border p-4 space-y-3 mb-4">
            <div className="grid grid-cols-2 gap-2">
              <Select value={fState} onValueChange={setFState}>
                <SelectTrigger><SelectValue placeholder="State" /></SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="__any">Any state</SelectItem>
                  {NIGERIA_STATES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
              <Input placeholder="Area" value={fArea} onChange={(e) => setFArea(e.target.value)} />
              <Select value={fType} onValueChange={setFType}>
                <SelectTrigger><SelectValue placeholder="Property" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__any">Any type</SelectItem>
                  {PROPERTY_TYPES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <Input inputMode="numeric" placeholder="Min ₦" value={fMin} onChange={(e) => setFMin(e.target.value.replace(/[^0-9]/g, ""))} />
              <Input inputMode="numeric" placeholder="Max ₦" value={fMax} onChange={(e) => setFMax(e.target.value.replace(/[^0-9]/g, ""))} />
            </div>
            <Button
              onClick={() => {
                if (fState === "__any") setFState("");
                if (fType === "__any") setFType("");
                runSearch();
              }}
              className="w-full"
            >
              Search
            </Button>
          </div>
          <div className="space-y-3">
            {search.length === 0 ? <Empty text="No requests match your filters." /> : search.map((r) => <RequestCard key={r.id} r={r} onChat={() => startChat(r)} />)}
          </div>
        </TabsContent>
      </Tabs>
    </AppShell>
  )
}

function Empty({ text }: { text: string }) {
  return <div className="rounded-2xl border-2 border-dashed p-8 text-center text-sm text-muted-foreground">{text}</div>;
}

function RequestCard({ r, onChat }: { r: Req; onChat: () => void }) {
  return (
    <div className="rounded-2xl border bg-card p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="font-semibold">{propertyLabel(r.property_type)}</div>
          <div className="text-sm text-muted-foreground flex items-center gap-1">
            <MapPin className="h-3.5 w-3.5" />{r.area}, {r.state}
          </div>
        </div>
        <Badge variant="secondary">{new Date(r.created_at).toLocaleDateString()}</Badge>
      </div>
      <div className="mt-2 text-sm">Budget: <strong>{formatNaira(r.min_budget)} – {formatNaira(r.max_budget)}</strong></div>
      {r.description && <p className="mt-2 text-sm text-muted-foreground line-clamp-3">{r.description}</p>}
      <div className="mt-3 flex gap-2">
        <Button onClick={onChat} className="flex-1 gap-1" size="sm"><MessageCircle className="h-4 w-4" /> Chat</Button>
        <a href={`tel:${r.phone}`}><Button variant="outline" size="sm" className="gap-1"><Phone className="h-4 w-4" /> Call</Button></a>
      </div>
    </div>
  );
}
