import { createFileRoute, redirect, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Phone, Send, Radar, Paperclip, Image as ImageIcon, Video, Mic, Square, Play, Pause, X } from "lucide-react";
import { propertyLabel, formatNaira } from "@/lib/constants";
import { toast } from "sonner";
import { sendPushTo } from "@/lib/push";
import { usePresence } from "@/hooks/use-presence";

export const Route = createFileRoute("/chats/$id")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  component: ChatRoom,
});

type Msg = {
  id: string;
  conversation_id: string;
  sender_id: string;
  body: string | null;
  media_url: string | null;
  media_type: string | null;
  duration_ms: number | null;
  created_at: string;
};

function ChatRoom() {
  const { id } = Route.useParams();
  const { user } = useAuth();
  const { isOnline } = usePresence();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [otherName, setOtherName] = useState("");
  const [otherPhone, setOtherPhone] = useState("");
  const [otherId, setOtherId] = useState<string>("");
  const [request, setRequest] = useState<any>(null);
  const [uploading, setUploading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recSeconds, setRecSeconds] = useState(0);
  const endRef = useRef<HTMLDivElement>(null);
  const imgInputRef = useRef<HTMLInputElement>(null);
  const vidInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recTimerRef = useRef<number | null>(null);
  const recStartedAtRef = useRef<number>(0);

  useEffect(() => {
    (async () => {
      const { data: c } = await supabase.from("conversations").select("*").eq("id", id).maybeSingle();
      if (c && user) {
        const otherId = c.client_id === user.id ? c.agent_id : c.client_id;
        setOtherId(otherId);
        const { data: p } = await supabase.from("profiles").select("full_name,phone").eq("id", otherId).maybeSingle();
        setOtherName(p?.full_name || "");
        setOtherPhone(p?.phone || "");
        const { data: r } = await supabase.from("requests").select("*").eq("id", c.request_id).maybeSingle();
        setRequest(r);
      }
      const { data: msgs } = await supabase.from("messages").select("*").eq("conversation_id", id).order("created_at");
      setMessages((msgs as Msg[]) ?? []);
    })();
  }, [id, user]);

  useEffect(() => {
    const ch = supabase.channel(`chat-${id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${id}` }, (payload) => {
        setMessages((prev) => [...prev, payload.new as Msg]);
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [id]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !user) return;
    const body = text.trim();
    setText("");
    await supabase.from("messages").insert({ conversation_id: id, sender_id: user.id, body });
    if (otherId) sendPushTo(otherId, "New message", body, `/chats/${id}`);
  };

  const uploadAndSend = async (file: Blob, type: "image" | "video" | "audio", ext: string, durationMs?: number) => {
    if (!user) return;
    setUploading(true);
    try {
      const path = `${user.id}/${id}/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("chat-media").upload(path, file, {
        contentType: file.type || `${type}/${ext}`,
      });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("chat-media").getPublicUrl(path);
      const { error: insErr } = await supabase.from("messages").insert({
        conversation_id: id,
        sender_id: user.id,
        body: "",
        media_url: pub.publicUrl,
        media_type: type,
        duration_ms: durationMs ?? null,
      });
      if (insErr) throw insErr;
      if (otherId) {
        const preview = type === "image" ? "📷 Photo" : type === "video" ? "🎥 Video" : "🎙️ Voice note";
        sendPushTo(otherId, "New message", preview, `/chats/${id}`);
      }
    } catch (err: any) {
      toast.error(err.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const onPickImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (f.size > 15 * 1024 * 1024) return toast.error("Image too large (max 15MB)");
    const ext = f.name.split(".").pop() || "jpg";
    await uploadAndSend(f, "image", ext);
  };

  const onPickVideo = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (f.size > 50 * 1024 * 1024) return toast.error("Video too large (max 50MB)");
    const ext = f.name.split(".").pop() || "mp4";
    await uploadAndSend(f, "video", ext);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunksRef.current = [];
      mr.ondataavailable = (ev) => { if (ev.data.size > 0) chunksRef.current.push(ev.data); };
      mr.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        const dur = Date.now() - recStartedAtRef.current;
        stream.getTracks().forEach((t) => t.stop());
        if (blob.size > 0) await uploadAndSend(blob, "audio", "webm", dur);
      };
      mediaRecorderRef.current = mr;
      recStartedAtRef.current = Date.now();
      mr.start();
      setRecording(true);
      setRecSeconds(0);
      recTimerRef.current = window.setInterval(() => setRecSeconds((s) => s + 1), 1000);
    } catch {
      toast.error("Microphone permission denied");
    }
  };

  const stopRecording = (cancel = false) => {
    const mr = mediaRecorderRef.current;
    if (!mr) return;
    if (cancel) mr.ondataavailable = null as any;
    mr.stop();
    if (recTimerRef.current) window.clearInterval(recTimerRef.current);
    setRecording(false);
    setRecSeconds(0);
  };

  return (
    <div className="min-h-screen flex flex-col bg-secondary/40">
      <header className="sticky top-0 z-30 border-b bg-background">
        <div className="max-w-3xl mx-auto px-3 h-14 flex items-center gap-2">
          <Link to="/chats"><Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button></Link>
          <div className="flex-1 min-w-0">
            <div className="font-semibold truncate flex items-center gap-2">
              {otherName || "Conversation"}
              {otherId && (
                <span
                  className={`h-2 w-2 rounded-full ${isOnline(otherId) ? "bg-green-500" : "bg-muted-foreground/40"}`}
                  aria-label={isOnline(otherId) ? "Online" : "Offline"}
                />
              )}
            </div>
            {otherId ? (
              <div className="text-xs text-muted-foreground truncate">
                {isOnline(otherId) ? "online" : "offline"}
                {request && ` · ${propertyLabel(request.property_type)} · ${request.area}, ${request.state}`}
              </div>
            ) : request && (
              <div className="text-xs text-muted-foreground truncate">
                {propertyLabel(request.property_type)} · {request.area}, {request.state}
              </div>
            )}
          </div>
          {otherPhone && (
            <a href={`tel:${otherPhone}`}><Button size="icon" variant="outline"><Phone className="h-4 w-4" /></Button></a>
          )}
        </div>
      </header>

      {request && (
        <div className="max-w-3xl mx-auto w-full px-3 pt-3">
          <div className="rounded-xl bg-primary/5 border border-primary/20 p-3 text-xs flex items-start gap-2">
            <Radar className="h-4 w-4 text-primary mt-0.5" />
            <div>
              <div className="font-medium text-foreground">{propertyLabel(request.property_type)} in {request.area}, {request.state}</div>
              <div className="text-muted-foreground">Budget {formatNaira(request.min_budget)} – {formatNaira(request.max_budget)}</div>
            </div>
          </div>
        </div>
      )}

      <main className="flex-1 max-w-3xl mx-auto w-full px-3 py-4 space-y-2 overflow-y-auto">
        {messages.length === 0 && (
          <div className="text-center text-sm text-muted-foreground py-10">Say hello 👋</div>
        )}
        {messages.map((m) => {
          const mine = m.sender_id === user?.id;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[78%] rounded-2xl px-2.5 py-2 text-sm shadow-sm ${mine ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-card rounded-bl-sm"}`}>
                {m.media_type === "image" && m.media_url && (
                  <a href={m.media_url} target="_blank" rel="noreferrer">
                    <img src={m.media_url} alt="" className="rounded-xl max-h-72 object-cover" />
                  </a>
                )}
                {m.media_type === "video" && m.media_url && (
                  <video src={m.media_url} controls className="rounded-xl max-h-72" />
                )}
                {m.media_type === "audio" && m.media_url && (
                  <VoiceNote url={m.media_url} mine={mine} duration={m.duration_ms ?? 0} />
                )}
                {m.body && <div className="whitespace-pre-wrap break-words px-1 py-0.5">{m.body}</div>}
                <div className={`text-[10px] mt-1 px-1 ${mine ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                  {new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </main>

      <input ref={imgInputRef} type="file" accept="image/*" hidden onChange={onPickImage} />
      <input ref={vidInputRef} type="file" accept="video/*" hidden onChange={onPickVideo} />

      <div className="sticky bottom-0 border-t bg-background">
        <div className="max-w-3xl mx-auto px-3 py-2">
          {recording ? (
            <div className="flex items-center gap-2">
              <Button type="button" variant="ghost" size="icon" onClick={() => stopRecording(true)}>
                <X className="h-5 w-5 text-destructive" />
              </Button>
              <div className="flex-1 flex items-center gap-2 rounded-full bg-destructive/10 px-3 py-2 text-destructive text-sm">
                <span className="h-2 w-2 rounded-full bg-destructive animate-pulse" />
                Recording… {formatTime(recSeconds * 1000)}
              </div>
              <Button type="button" size="icon" className="rounded-full" onClick={() => stopRecording(false)}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <form onSubmit={send} className="flex gap-2 items-center">
              <AttachMenu
                onImage={() => imgInputRef.current?.click()}
                onVideo={() => vidInputRef.current?.click()}
                disabled={uploading}
              />
              <Input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={uploading ? "Uploading…" : "Type a message"}
                className="rounded-full"
                disabled={uploading}
              />
              {text.trim() ? (
                <Button type="submit" size="icon" className="rounded-full"><Send className="h-4 w-4" /></Button>
              ) : (
                <Button type="button" size="icon" className="rounded-full" onClick={startRecording} disabled={uploading}>
                  <Mic className="h-4 w-4" />
                </Button>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

function AttachMenu({ onImage, onVideo, disabled }: { onImage: () => void; onVideo: () => void; disabled?: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <Button type="button" variant="ghost" size="icon" onClick={() => setOpen((o) => !o)} disabled={disabled}>
        <Paperclip className="h-5 w-5" />
      </Button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute bottom-12 left-0 z-20 rounded-xl border bg-popover shadow-md p-1 w-40">
            <button type="button" className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-accent/20 rounded-lg" onClick={() => { setOpen(false); onImage(); }}>
              <ImageIcon className="h-4 w-4" /> Photo
            </button>
            <button type="button" className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-accent/20 rounded-lg" onClick={() => { setOpen(false); onVideo(); }}>
              <Video className="h-4 w-4" /> Video
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function VoiceNote({ url, mine, duration }: { url: string; mine: boolean; duration: number }) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0);
  const [dur, setDur] = useState(duration / 1000);

  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (playing) { a.pause(); } else { a.play(); }
  };

  return (
    <div className={`flex items-center gap-2 px-1 py-1 min-w-[180px]`}>
      <button type="button" onClick={toggle} className={`h-9 w-9 rounded-full flex items-center justify-center ${mine ? "bg-primary-foreground/20" : "bg-primary/10 text-primary"}`}>
        {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
      </button>
      <div className="flex-1">
        <div className={`h-1 rounded-full ${mine ? "bg-primary-foreground/30" : "bg-muted"}`}>
          <div
            className={`h-1 rounded-full ${mine ? "bg-primary-foreground" : "bg-primary"}`}
            style={{ width: dur > 0 ? `${Math.min(100, (pos / dur) * 100)}%` : "0%" }}
          />
        </div>
        <div className={`text-[10px] mt-1 ${mine ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
          {formatTime((playing || pos > 0 ? pos : dur) * 1000)}
        </div>
      </div>
      <audio
        ref={audioRef}
        src={url}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => { setPlaying(false); setPos(0); }}
        onTimeUpdate={(e) => setPos(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => {
          const d = e.currentTarget.duration;
          if (isFinite(d) && d > 0) setDur(d);
        }}
        preload="metadata"
      />
    </div>
  );
}

function formatTime(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}
