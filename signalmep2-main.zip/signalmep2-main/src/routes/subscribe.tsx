import { createFileRoute, redirect, useRouter } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Sparkles, Crown } from "lucide-react";
import { toast } from "sonner";
import { PRO_PRICE_NAIRA } from "@/lib/subscription.functions";

declare global {
  interface Window {
    FlutterwaveCheckout?: (opts: any) => void;
  }
}

const search = z.object({
  autostart: z.enum(["trial", "pro"]).optional(),
});

export const Route = createFileRoute("/subscribe")({
  validateSearch: (s) => search.parse(s),
  beforeLoad: async () => {
    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();
    if (error || !user) throw redirect({ to: "/auth" });
  },
  component: SubscribePage,
});

function loadFlutterwaveScript(): Promise<void> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined") return resolve();
    if (window.FlutterwaveCheckout) return resolve();
    const s = document.createElement("script");
    s.src = "https://checkout.flutterwave.com/v3.js";
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("Failed to load Flutterwave"));
    document.body.appendChild(s);
  });
}

async function fetchMySubscription(userId: string) {
  const { data, error } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
}

async function fetchFlutterwaveKey(): Promise<string> {
  const res = await fetch("/api/payments/flutterwave-config");
  if (!res.ok) return "";
  const j = await res.json().catch(() => ({}));
  return j.publicKey ?? "";
}

function SubscribePage() {
  const { user, profile } = useAuth();
  const router = useRouter();
  const { autostart } = Route.useSearch();

  const subQ = useQuery({
    queryKey: ["my-sub", user?.id],
    queryFn: () => fetchMySubscription(user!.id),
    enabled: !!user,
  });
  const keyQ = useQuery({
    queryKey: ["fw-pk"],
    queryFn: fetchFlutterwaveKey,
  });

  const [loading, setLoading] = useState<"trial" | "pro" | null>(null);
  const autoStartedRef = useRef(false);

  useEffect(() => {
    loadFlutterwaveScript().catch(() => {});
  }, []);

  const sub = subQ.data;
  const isActive =
    sub && sub.status === "active" && new Date(sub.current_period_end) > new Date();

  const onTrial = async () => {
    if (!user) return;
    try {
      setLoading("trial");
      // Re-check current sub to enforce one-time trial.
      const { data: existing } = await supabase
        .from("subscriptions")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (existing?.trial_used) {
        throw new Error("You have already used your free trial.");
      }

      const periodEnd = new Date();
      periodEnd.setDate(periodEnd.getDate() + 30);

      if (existing) {
        const { error } = await supabase
          .from("subscriptions")
          .update({
            plan: "trial",
            status: "active",
            current_period_end: periodEnd.toISOString(),
            trial_used: true,
            updated_at: new Date().toISOString(),
          })
          .eq("user_id", user.id);
        if (error) throw new Error(error.message);
      } else {
        const { error } = await supabase.from("subscriptions").insert({
          user_id: user.id,
          plan: "trial",
          status: "active",
          current_period_end: periodEnd.toISOString(),
          trial_used: true,
        });
        if (error) throw new Error(error.message);
      }

      toast.success("Free trial activated for 30 days!");
      await subQ.refetch();
      router.navigate({ to: "/agent" });
    } catch (e: any) {
      toast.error(e.message || "Could not start trial");
    } finally {
      setLoading(null);
    }
  };

  const onPro = async () => {
    if (!user) return;
    const pk = keyQ.data || (await fetchFlutterwaveKey());
    if (!pk) {
      toast.error("Payment not configured. Please contact support.");
      return;
    }
    await loadFlutterwaveScript();
    if (!window.FlutterwaveCheckout) {
      toast.error("Could not load payment. Check your connection.");
      return;
    }
    const tx_ref = `signalme-${user.id}-${Date.now()}`;
    setLoading("pro");
    window.FlutterwaveCheckout({
      public_key: pk,
      tx_ref,
      amount: PRO_PRICE_NAIRA,
      currency: "NGN",
      payment_options: "card,banktransfer,ussd,account",
      customer: {
        email: user.email ?? "",
        name: profile?.full_name ?? "",
        phonenumber: profile?.phone ?? "",
      },
      customizations: {
        title: "SignalMe Agent Pro",
        description: "Monthly Agent Pro subscription",
        logo: `${window.location.origin}/icon-192.png`,
      },
      callback: async (resp: any) => {
        try {
          if (resp.status === "successful" || resp.status === "completed") {
            const { data: sess } = await supabase.auth.getSession();
            const token = sess.session?.access_token;
            const verifyRes = await fetch(
              "/api/payments/verify-flutterwave",
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${token ?? ""}`,
                },
                body: JSON.stringify({
                  transaction_id: String(resp.transaction_id),
                  tx_ref,
                }),
              },
            );
            const verifyJson = await verifyRes
              .json()
              .catch(() => ({ error: "Invalid server response" }));
            if (!verifyRes.ok || verifyJson?.ok === false) {
              throw new Error(verifyJson?.error || "Verification failed");
            }
            toast.success("Agent Pro activated!");
            await subQ.refetch();
            router.navigate({ to: "/agent" });
          } else {
            toast.error("Payment was not completed.");
          }
        } catch (e: any) {
          toast.error(e.message || "Verification failed");
        } finally {
          setLoading(null);
        }
      },
      onclose: () => setLoading(null),
    });
  };

  // Auto-start the chosen flow when arriving from signup with a pre-selected plan
  useEffect(() => {
    if (autoStartedRef.current) return;
    if (!autostart) return;
    if (!user) return;
    if (subQ.isLoading || keyQ.isLoading) return;
    if (isActive) return;

    if (autostart === "trial" && !sub?.trial_used) {
      autoStartedRef.current = true;
      onTrial();
    } else if (autostart === "pro") {
      autoStartedRef.current = true;
      onPro();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autostart, user, subQ.isLoading, keyQ.isLoading, isActive, sub?.trial_used]);

  return (
    <AppShell>
      <section
        className="rounded-2xl p-6 text-primary-foreground shadow-lg"
        style={{ background: "var(--gradient-primary)" }}
      >
        <div className="flex items-center gap-2 text-xs uppercase tracking-wider opacity-80">
          <Crown className="h-3.5 w-3.5" /> Subscription
        </div>
        <h1 className="text-2xl font-bold mt-1">Unlock Agent Pro</h1>
        <p className="text-sm opacity-90 mt-1">
          Get early access to new requests, boosted visibility and the priority Signal Matrix.
        </p>
      </section>

      {isActive && (
        <div className="rounded-2xl border-l-4 border-l-primary bg-primary/5 p-4 mt-5">
          <strong className="capitalize">{sub.plan} plan active</strong>
          <p className="text-sm text-muted-foreground mt-1">
            {sub.plan === "trial" ? "Trial ends" : "Renews / expires"} on{" "}
            {new Date(sub.current_period_end).toLocaleDateString()}.
          </p>
        </div>
      )}

      {sub && !isActive && (
        <div className="rounded-2xl border-l-4 border-l-destructive bg-destructive/5 p-4 mt-5">
          <strong className="capitalize">{sub.plan} plan expired</strong>
          <p className="text-sm text-muted-foreground mt-1">
            Your {sub.plan} ended on{" "}
            {new Date(sub.current_period_end).toLocaleDateString()}. Subscribe to Agent Pro to keep receiving early signals.
          </p>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4 mt-6">
        <div className="rounded-2xl border bg-card p-6">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="font-semibold">Free Trial</span>
          </div>
          <div className="text-3xl font-extrabold mt-2">
            ₦0 <span className="text-base font-normal text-muted-foreground">/ first month</span>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Full Agent Pro access for 30 days. One per agent — expires automatically.
          </p>
          <ul className="mt-4 space-y-2 text-sm">
            <Feat>All Agent Pro features</Feat>
            <Feat>Early access to new requests</Feat>
            <Feat>Priority Signal Matrix</Feat>
            <Feat>No card required</Feat>
          </ul>
          <Button
            className="w-full mt-5"
            variant="outline"
            disabled={loading !== null || sub?.trial_used}
            onClick={onTrial}
          >
            {sub?.trial_used
              ? "Trial already used"
              : loading === "trial"
                ? "Starting…"
                : "Start free trial"}
          </Button>
        </div>

        <div className="rounded-2xl border-2 border-primary bg-card p-6 relative shadow-xl">
          <div className="absolute -top-3 left-6 bg-primary text-primary-foreground text-xs font-semibold px-2.5 py-1 rounded-full">
            Most popular
          </div>
          <div className="flex items-center gap-2">
            <Crown className="h-4 w-4 text-primary" />
            <span className="font-semibold">Agent Pro</span>
          </div>
          <div className="text-3xl font-extrabold mt-2">
            ₦{PRO_PRICE_NAIRA.toLocaleString()}
            <span className="text-base font-normal text-muted-foreground">/mo</span>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Pay securely via card, transfer or USSD with Flutterwave.
          </p>
          <ul className="mt-4 space-y-2 text-sm">
            <Feat>Early access to new requests</Feat>
            <Feat>Boosted visibility</Feat>
            <Feat>Priority Signal Matrix</Feat>
            <Feat>Cancel anytime</Feat>
          </ul>
          <Button className="w-full mt-5" disabled={loading !== null} onClick={onPro}>
            {loading === "pro" ? "Processing…" : `Subscribe — ₦${PRO_PRICE_NAIRA.toLocaleString()}/mo`}
          </Button>
        </div>
      </div>

      <p className="text-xs text-muted-foreground mt-6 text-center">
        Payments are processed securely by Flutterwave. SignalMe never stores your card details.
      </p>

      <div className="mt-6 text-center">
        <Button variant="ghost" onClick={() => router.navigate({ to: "/agent" })}>
          Back to dashboard
        </Button>
      </div>
    </AppShell>
  );
}

function Feat({ children }: { children: React.ReactNode }) {
  return (
    <li className="flex gap-2">
      <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" /> {children}
    </li>
  );
}
