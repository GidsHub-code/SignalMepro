import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { useUnreadChats } from "@/hooks/use-unread-chats";
import { usePresence } from "@/hooks/use-presence";
import { AppShell } from "@/components/AppShell";
import { propertyLabel } from "@/lib/constants";
import { MessageCircle } from "lucide-react";

export const Route = createFileRoute("/chats/")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  component: ChatsList,
});

function ChatsList() {
  const { user, profile } = useAuth();
  const { counts } = useUnreadChats();
  const { isOnline } = usePresence();
  const [rows, setRows] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: convs } = await supabase
        .from("conversations").select("*")
        .or(`client_id.eq.${user.id},agent_id.eq.${user.id}`)
        .order("created_at", { ascending: false });
      const list = (convs as any[]) ?? [];
      const otherIds = Array.from(new Set(list.map((c) => (c.client_id === user.id ? c.agent_id : c.client_id))));
      const reqIds = Array.from(new Set(list.map((c) => c.request_id)));
      const [{ data: profs }, { data: reqs }] = await Promise.all([
        otherIds.length ? supabase.from("profiles").select("id,full_name").in("id", otherIds) : Promise.resolve({ data: [] as any }),
        reqIds.length ? supabase.from("requests").select("id,property_type,state,area").in("id", reqIds) : Promise.resolve({ data: [] as any }),
      ]);
      const pMap = new Map((profs ?? []).map((p: any) => [p.id, p]));
      const rMap = new Map((reqs ?? []).map((r: any) => [r.id, r]));
      setRows(list.map((c) => ({
        ...c,
        other: pMap.get(c.client_id === user.id ? c.agent_id : c.client_id),
        request: rMap.get(c.request_id),
      })));
    })();
  }, [user]);

  return (
    <AppShell>
      <h1 className="text-2xl font-bold mb-4">Chats</h1>
      {rows.length === 0 ? (
        <div className="rounded-2xl border-2 border-dashed p-8 text-center text-sm text-muted-foreground">
          No conversations yet.
        </div>
      ) : (
        <div className="space-y-2">
          {rows.map((c) => {
            const otherName = c.other?.full_name;
            const otherId = c.client_id === user?.id ? c.agent_id : c.client_id;
            const unread = counts[c.id] || 0;
            const online = otherId ? isOnline(otherId) : false;
            return (
              <Link key={c.id} to="/chats/$id" params={{ id: c.id }} className="block rounded-2xl border bg-card p-4 hover:bg-secondary/40 transition">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="h-10 w-10 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                      <MessageCircle className="h-5 w-5" />
                    </div>
                    <span
                      className={`absolute bottom-0 right-0 h-3 w-3 rounded-full ring-2 ring-card ${online ? "bg-green-500" : "bg-muted-foreground/40"}`}
                      aria-label={online ? "Online" : "Offline"}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <div className={`truncate ${unread > 0 ? "font-semibold" : "font-medium"}`}>{otherName ?? (profile?.role === "agent" ? "Renter" : "Agent")}</div>
                      <span className={`text-[10px] ${online ? "text-green-600" : "text-muted-foreground"}`}>
                        {online ? "online" : "offline"}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                      {c.request ? `${propertyLabel(c.request.property_type)} · ${c.request.area}, ${c.request.state}` : "Conversation"}
                    </div>
                  </div>
                  {unread > 0 && (
                    <span className="min-w-[22px] h-[22px] px-1.5 rounded-full bg-destructive text-destructive-foreground text-[11px] font-semibold flex items-center justify-center">
                      {unread > 99 ? "99+" : unread}
                    </span>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
