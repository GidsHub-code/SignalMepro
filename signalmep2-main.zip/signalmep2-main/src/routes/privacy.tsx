import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead } from "@/lib/seo";

export const Route = createFileRoute("/privacy")({
  head: () =>
    buildHead({
      title: "Privacy Policy — SignalMe",
      description:
        "How SignalMe collects, uses, and protects your personal information when you rent a house, post a request, or work as an agent in Nigeria.",
      path: "/privacy",
    }),
  component: Privacy,
});

function Privacy() {
  return (
    <main className="max-w-3xl mx-auto px-5 py-12 prose prose-sm">
      <Link to="/" className="text-primary text-sm">← Home</Link>
      <h1 className="text-3xl font-bold mt-4 mb-6">Privacy Policy</h1>
      <p className="text-sm text-muted-foreground">Last updated: May 2026</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">Information we collect</h2>
      <p>We collect your name, email, phone number, and rental request details when you sign up and use SignalMe. We also collect device and usage data to improve the service.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">How we use your data</h2>
      <p>We use your data to match you with verified agents, send notifications, secure your account, and improve SignalMe. We never sell your personal information.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">Cookies & advertising</h2>
      <p>SignalMe uses cookies for authentication and analytics. We may display ads served by third parties such as Google AdSense, which may use cookies to serve ads based on your prior visits to this and other websites. You can opt out via <a href="https://www.google.com/settings/ads" className="text-primary underline">Google Ads Settings</a>.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">Data retention & rights</h2>
      <p>You may request deletion of your account and personal data at any time by contacting support. We retain data only as long as needed to provide the service.</p>
      <h2 className="text-xl font-semibold mt-6 mb-2">Contact</h2>
      <p>Email: support@signalmepro.lovable.app</p>
    </main>
  );
}
