import { createFileRoute, Link, redirect, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { NIGERIA_STATES, PROPERTY_TYPES, formatNaira, propertyLabel } from "@/lib/constants";
import { Plus, AlertTriangle, MapPin, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/request")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  component: ClientRequestsPage,
});

type Req = {
  id: string;
  property_type: string;
  state: string;
  area: string;
  min_budget: number;
  max_budget: number;
  phone: string;
  description: string;
  status: "open" | "closed";
  created_at: string;
};

function ClientRequestsPage() {
  const { profile, user } = useAuth();
  const [requests, setRequests] = useState<Req[]>([]);
  const [open, setOpen] = useState(false);
  const router = useRouter();

  const load = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("requests")
      .select("*")
      .eq("client_id", user.id)
      .order("created_at", { ascending: false });
    setRequests((data as Req[]) ?? []);
  };

  useEffect(() => { load(); }, [user]);
  useEffect(() => {
    if (profile?.role === "agent") router.navigate({ to: "/agent" });
  }, [profile]);

  const closeReq = async (id: string) => {
    await supabase.from("requests").update({ status: "closed" }).eq("id", id);
    toast.success("Request closed");
    load();
  };

  return (
    <AppShell>
      <div className="flex items-center gap-2 mb-4">
        <Link to="/client"><Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button></Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold leading-tight">My requests</h1>
          <p className="text-sm text-muted-foreground">Manage your rental searches</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-1"><Plus className="h-4 w-4" /> New</Button>
          </DialogTrigger>
          <NewRequestDialog onCreated={() => { setOpen(false); load(); }} defaultPhone={profile?.phone || ""} />
        </Dialog>
      </div>

      {requests.length === 0 ? (
        <EmptyState onClick={() => setOpen(true)} />
      ) : (
        <div className="space-y-3">
          {requests.map((r) => (
            <div key={r.id} className="rounded-2xl border bg-card p-4 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{propertyLabel(r.property_type)}</div>
                  <div className="text-sm text-muted-foreground flex items-center gap-1">
                    <MapPin className="h-3.5 w-3.5" />{r.area}, {r.state}
                  </div>
                </div>
                <Badge variant={r.status === "open" ? "default" : "secondary"}>{r.status}</Badge>
              </div>
              <div className="mt-3 text-sm">
                Budget: <strong>{formatNaira(r.min_budget)} – {formatNaira(r.max_budget)}</strong>
              </div>
              {r.description && <p className="mt-2 text-sm text-muted-foreground">{r.description}</p>}
              <div className="mt-3 flex gap-2">
                <Link to="/chats" className="flex-1"><Button variant="secondary" className="w-full" size="sm">View chats</Button></Link>
                {r.status === "open" && (
                  <Button onClick={() => closeReq(r.id)} variant="outline" size="sm">Close</Button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}

function EmptyState({ onClick }: { onClick: () => void }) {
  return (
    <div className="rounded-2xl border-2 border-dashed p-10 text-center">
      <h2 className="font-semibold text-lg">Post your first request</h2>
      <p className="text-sm text-muted-foreground mt-1">
        Tell us what you're looking for and verified agents in your area will be signaled.
      </p>
      <Button onClick={onClick} className="mt-4 gap-1"><Plus className="h-4 w-4" /> New request</Button>
    </div>
  );
}

function NewRequestDialog({ onCreated, defaultPhone }: { onCreated: () => void; defaultPhone: string }) {
  const { user } = useAuth();
  const [property_type, setPT] = useState<string>("");
  const [state, setState] = useState("");
  const [area, setArea] = useState("");
  const [min_budget, setMin] = useState("");
  const [max_budget, setMax] = useState("");
  const [phone, setPhone] = useState(defaultPhone);
  const [description, setDescription] = useState("");
  const [ack, setAck] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!property_type || !state || !area || !min_budget || !max_budget || !phone) {
      toast.error("Please fill all required fields");
      return;
    }
    if (Number(min_budget) > Number(max_budget)) {
      toast.error("Min budget cannot exceed max budget");
      return;
    }
    if (!ack) {
      toast.error("Please acknowledge the safety notice");
      return;
    }
    setLoading(true);
    const { error } = await supabase.from("requests").insert({
      client_id: user.id,
      property_type: property_type as any,
      state, area,
      min_budget: Number(min_budget),
      max_budget: Number(max_budget),
      phone, description,
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Request posted — agents are being signaled");
    onCreated();
  };

  return (
    <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
      <DialogHeader><DialogTitle>New rental request</DialogTitle></DialogHeader>
      <form onSubmit={submit} className="space-y-4">
        <div>
          <Label>Property type</Label>
          <Select value={property_type} onValueChange={setPT}>
            <SelectTrigger><SelectValue placeholder="Choose…" /></SelectTrigger>
            <SelectContent>{PROPERTY_TYPES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>State</Label>
            <Select value={state} onValueChange={setState}>
              <SelectTrigger><SelectValue placeholder="Choose…" /></SelectTrigger>
              <SelectContent className="max-h-72">{NIGERIA_STATES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Area</Label>
            <Input value={area} onChange={(e) => setArea(e.target.value)} placeholder="e.g. Yaba" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Min budget (₦)</Label>
            <Input inputMode="numeric" value={min_budget} onChange={(e) => setMin(e.target.value.replace(/[^0-9]/g, ""))} />
          </div>
          <div>
            <Label>Max budget (₦)</Label>
            <Input inputMode="numeric" value={max_budget} onChange={(e) => setMax(e.target.value.replace(/[^0-9]/g, ""))} />
          </div>
        </div>
        <div>
          <Label>Phone number</Label>
          <Input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
        <div>
          <Label>Description (optional)</Label>
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Preferences, urgency, features…" />
        </div>

        <div className="rounded-lg border-l-4 border-l-accent bg-accent/10 p-3 text-sm flex gap-2">
          <AlertTriangle className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
          <div>
            <strong>Important Notice:</strong> Do not make any payment for a house for rent
            to an agent without seeing the house physically.
            <label className="flex items-center gap-2 mt-2">
              <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} />
              <span>I understand</span>
            </label>
          </div>
        </div>

        <DialogFooter>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Posting…" : "Post request"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )
}
