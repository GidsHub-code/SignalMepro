import { createFileRoute, Link, redirect, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Plus, FileText, MessageSquare, Radar, Sparkles, ShieldCheck, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/client")({
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
  },
  component: ClientHome,
});

function ClientHome() {
  const { profile, user } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState({ open: 0, total: 0, chats: 0 });

  useEffect(() => {
    if (profile?.role === "agent") router.navigate({ to: "/agent" });
  }, [profile]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: reqs } = await supabase.from("requests").select("id,status").eq("client_id", user.id);
      const { count: chatCount } = await supabase
        .from("conversations").select("*", { count: "exact", head: true }).eq("client_id", user.id);
      const list = reqs ?? [];
      setStats({
        open: list.filter((r: any) => r.status === "open").length,
        total: list.length,
        chats: chatCount ?? 0,
      });
    })();
  }, [user]);

  return (
    <AppShell>
      <section className="rounded-2xl p-6 text-primary-foreground shadow-lg" style={{ background: "var(--gradient-primary)" }}>
        <div className="flex items-center gap-2 text-xs uppercase tracking-wider opacity-80">
          <Radar className="h-3.5 w-3.5" /> Renter dashboard
        </div>
        <h1 className="text-2xl font-bold mt-1">Welcome, {profile?.full_name?.split(" ")[0] || "there"} 👋</h1>
        <p className="text-sm opacity-90 mt-1">
          Tell us what you're looking for and verified agents in your area get signaled instantly.
        </p>
        <Button asChild variant="secondary" className="mt-4 gap-1">
          <Link to="/request">
            <Plus className="h-4 w-4" /> Post a new request
          </Link>
        </Button>
      </section>

      <div className="grid grid-cols-3 gap-3 mt-5">
        <StatCard label="Open" value={stats.open} />
        <StatCard label="Total" value={stats.total} />
        <StatCard label="Chats" value={stats.chats} />
      </div>

      <h2 className="font-semibold mt-6 mb-3">Quick actions</h2>
      <div className="space-y-3">
        <ActionCard
          to="/request"
          icon={FileText}
          title="My requests"
          desc="View, manage and post new rental requests"
        />
        <ActionCard
          to="/chats"
          icon={MessageSquare}
          title="Messages"
          desc="Chat with verified agents who reached out"
        />
        <ActionCard
          to="/profile"
          icon={ShieldCheck}
          title="Profile"
          desc="Update your details and account info"
        />
      </div>

      <div className="rounded-2xl border-l-4 border-l-accent bg-accent/10 p-4 mt-6 flex gap-3">
        <Sparkles className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
        <div className="text-sm">
          <strong>How SignalMe works</strong>
          <p className="text-muted-foreground mt-1">
            Post a request → matching agents are auto-signaled → they message you with options.
            Never pay before physically inspecting a property.
          </p>
        </div>
      </div>
    </AppShell>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border bg-card p-4 text-center">
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}

function ActionCard({ to, icon: Icon, title, desc }: { to: string; icon: any; title: string; desc: string }) {
  return (
    <Link to={to as any} className="flex items-center gap-3 rounded-2xl border bg-card p-4 hover:border-primary transition-colors">
      <span className="h-10 w-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
        <Icon className="h-5 w-5" />
      </span>
      <div className="flex-1 min-w-0">
        <div className="font-medium">{title}</div>
        <div className="text-xs text-muted-foreground truncate">{desc}</div>
      </div>
      <ArrowRight className="h-4 w-4 text-muted-foreground" />
    </Link>
  );
}
