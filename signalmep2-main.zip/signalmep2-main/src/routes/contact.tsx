import { createFileRoute, Link } from "@tanstack/react-router";
import { buildHead, breadcrumbJsonLd } from "@/lib/seo";

export const Route = createFileRoute("/contact")({
  head: () =>
    buildHead({
      title: "Contact SignalMe — Real Estate Support in Nigeria",
      description:
        "Reach the SignalMe team for support, partnerships, agent verification, press or feedback about renting houses, flats, shortlets and offices in Nigeria.",
      path: "/contact",
      keywords:
        "contact SignalMe, real estate support Nigeria, rental help Lagos, agent verification, property platform contact",
      jsonLd: breadcrumbJsonLd([{ name: "Home", path: "/" }, { name: "Contact", path: "/contact" }]),
    }),
  component: Contact,
});

function Contact() {
  return (
    <main className="max-w-3xl mx-auto px-5 py-12">
      <Link to="/" className="text-primary text-sm">← Home</Link>
      <h1 className="text-3xl font-bold mt-4 mb-6">Contact</h1>
      <p>For support, partnerships or press, email us at <a className="text-primary underline" href="mailto:support@signalmepro.lovable.app">support@signalmepro.lovable.app</a>.</p>
      <div className="mt-6 flex gap-4 text-sm">
        <a className="text-primary underline" href="https://www.facebook.com/share/17YdcwYHz2/" target="_blank" rel="noopener noreferrer">Facebook</a>
        <a className="text-primary underline" href="https://www.instagram.com/signalme_1?igsh=eXcyaDJ3b2xjdzZ0" target="_blank" rel="noopener noreferrer">Instagram</a>
        <a className="text-primary underline" href="https://www.tiktok.com/@signalme_?_r=1&_t=ZS-969GuCtNKy5" target="_blank" rel="noopener noreferrer">TikTok</a>
      </div>
    </main>
  );
}
