REVOKE EXECUTE ON FUNCTION public.invoke_send_push(text, jsonb) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.on_notification_insert_push() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.on_message_insert_push() FROM PUBLIC, anon, authenticated;