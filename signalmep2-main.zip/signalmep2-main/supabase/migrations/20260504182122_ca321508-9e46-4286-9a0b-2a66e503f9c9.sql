
-- Roles enum
CREATE TYPE public.user_role AS ENUM ('client','agent');
CREATE TYPE public.property_type AS ENUM ('shop','office','hall','duplex','warehouse','1_room','selfcon','room_and_parlour','2_bed_flat','3_bed_flat');
CREATE TYPE public.request_status AS ENUM ('open','closed');

-- Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  role public.user_role NOT NULL DEFAULT 'client',
  verified BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles read all authenticated" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "profiles insert own" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles update own" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);

-- Auto create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name',''),
    COALESCE(NEW.raw_user_meta_data->>'phone',''),
    COALESCE((NEW.raw_user_meta_data->>'role')::public.user_role,'client')
  );
  RETURN NEW;
END;$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Agent preferences (Signal Matrix)
CREATE TABLE public.agent_preferences (
  agent_id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  states TEXT[] NOT NULL DEFAULT '{}',
  areas TEXT[] NOT NULL DEFAULT '{}',
  property_types public.property_type[] NOT NULL DEFAULT '{}',
  min_budget BIGINT NOT NULL DEFAULT 0,
  max_budget BIGINT NOT NULL DEFAULT 1000000000,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.agent_preferences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "agent prefs read own" ON public.agent_preferences FOR SELECT TO authenticated USING (auth.uid() = agent_id);
CREATE POLICY "agent prefs upsert own" ON public.agent_preferences FOR INSERT TO authenticated WITH CHECK (auth.uid() = agent_id);
CREATE POLICY "agent prefs update own" ON public.agent_preferences FOR UPDATE TO authenticated USING (auth.uid() = agent_id);

-- Requests
CREATE TABLE public.requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  property_type public.property_type NOT NULL,
  state TEXT NOT NULL,
  area TEXT NOT NULL,
  min_budget BIGINT NOT NULL,
  max_budget BIGINT NOT NULL,
  phone TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  status public.request_status NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.requests ENABLE ROW LEVEL SECURITY;
CREATE INDEX ON public.requests (state, area, property_type);
CREATE INDEX ON public.requests (client_id);

-- Helper: is current user agent
CREATE OR REPLACE FUNCTION public.is_agent(_uid UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _uid AND role = 'agent');
$$;

CREATE POLICY "requests client read own" ON public.requests FOR SELECT TO authenticated
  USING (auth.uid() = client_id OR public.is_agent(auth.uid()));
CREATE POLICY "requests client insert own" ON public.requests FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = client_id);
CREATE POLICY "requests client update own" ON public.requests FOR UPDATE TO authenticated
  USING (auth.uid() = client_id);

-- Conversations (one per request+agent)
CREATE TABLE public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id UUID NOT NULL REFERENCES public.requests(id) ON DELETE CASCADE,
  client_id UUID NOT NULL,
  agent_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(request_id, agent_id)
);
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "conv participant read" ON public.conversations FOR SELECT TO authenticated
  USING (auth.uid() = client_id OR auth.uid() = agent_id);
CREATE POLICY "conv agent create" ON public.conversations FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = agent_id AND public.is_agent(auth.uid()));

CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE INDEX ON public.messages(conversation_id, created_at);

CREATE POLICY "msg participant read" ON public.messages FOR SELECT TO authenticated
  USING (EXISTS(SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND (c.client_id = auth.uid() OR c.agent_id = auth.uid())));
CREATE POLICY "msg participant send" ON public.messages FOR INSERT TO authenticated
  WITH CHECK (sender_id = auth.uid() AND EXISTS(SELECT 1 FROM public.conversations c WHERE c.id = conversation_id AND (c.client_id = auth.uid() OR c.agent_id = auth.uid())));

-- Notifications
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  link TEXT,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE INDEX ON public.notifications(user_id, created_at DESC);
CREATE POLICY "notif read own" ON public.notifications FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "notif update own" ON public.notifications FOR UPDATE TO authenticated USING (auth.uid() = user_id);

-- Signal Matrix: when a request is inserted, notify matching agents
CREATE OR REPLACE FUNCTION public.match_request_to_agents()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.notifications (user_id, title, body, link)
  SELECT
    p.agent_id,
    'New matching request',
    NEW.property_type::text || ' in ' || NEW.area || ', ' || NEW.state,
    '/agent/requests/' || NEW.id::text
  FROM public.agent_preferences p
  WHERE NEW.state = ANY(p.states)
    AND (cardinality(p.areas) = 0 OR NEW.area = ANY(p.areas))
    AND NEW.property_type = ANY(p.property_types)
    AND NEW.max_budget >= p.min_budget
    AND NEW.min_budget <= p.max_budget;
  RETURN NEW;
END;$$;
CREATE TRIGGER trg_match_request AFTER INSERT ON public.requests
  FOR EACH ROW EXECUTE FUNCTION public.match_request_to_agents();

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.requests;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;
