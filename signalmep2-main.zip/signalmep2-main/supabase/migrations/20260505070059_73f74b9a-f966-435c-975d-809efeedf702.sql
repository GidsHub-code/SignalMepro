-- Messages: support media (image/video/audio voice notes)
ALTER TABLE public.messages
  ADD COLUMN IF NOT EXISTS media_url text,
  ADD COLUMN IF NOT EXISTS media_type text,
  ADD COLUMN IF NOT EXISTS duration_ms integer;

ALTER TABLE public.messages ALTER COLUMN body SET DEFAULT '';
ALTER TABLE public.messages ALTER COLUMN body DROP NOT NULL;

-- Storage bucket for chat media (images, videos, voice notes)
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-media', 'chat-media', true)
ON CONFLICT (id) DO NOTHING;

-- Public read
DROP POLICY IF EXISTS "chat-media public read" ON storage.objects;
CREATE POLICY "chat-media public read"
ON storage.objects FOR SELECT
USING (bucket_id = 'chat-media');

-- Authenticated users can upload to their own folder: <uid>/...
DROP POLICY IF EXISTS "chat-media auth upload" ON storage.objects;
CREATE POLICY "chat-media auth upload"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'chat-media' AND auth.uid()::text = (storage.foldername(name))[1]);

DROP POLICY IF EXISTS "chat-media auth update" ON storage.objects;
CREATE POLICY "chat-media auth update"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'chat-media' AND auth.uid()::text = (storage.foldername(name))[1]);

DROP POLICY IF EXISTS "chat-media auth delete" ON storage.objects;
CREATE POLICY "chat-media auth delete"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'chat-media' AND auth.uid()::text = (storage.foldername(name))[1]);