-- Enable pg_net for HTTP calls from triggers
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Helper: invoke the send-push edge function with a record payload
CREATE OR REPLACE FUNCTION public.invoke_send_push(_table text, _record jsonb)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, extensions
AS $$
DECLARE
  _url text := 'https://ronuglfvyfpcxvgqusqg.supabase.co/functions/v1/send-push';
  _key text;
BEGIN
  -- service role for invoking the (verify_jwt=false) function; harmless if function is public
  _key := current_setting('app.settings.service_role_key', true);
  PERFORM net.http_post(
    url := _url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json'
    ),
    body := jsonb_build_object(
      'table', _table,
      'type', 'INSERT',
      'record', _record
    )
  );
END;
$$;

-- Trigger function for notifications
CREATE OR REPLACE FUNCTION public.on_notification_insert_push()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM public.invoke_send_push('notifications', to_jsonb(NEW));
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS notifications_push_trigger ON public.notifications;
CREATE TRIGGER notifications_push_trigger
AFTER INSERT ON public.notifications
FOR EACH ROW EXECUTE FUNCTION public.on_notification_insert_push();

-- Trigger function for messages
CREATE OR REPLACE FUNCTION public.on_message_insert_push()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM public.invoke_send_push('messages', to_jsonb(NEW));
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS messages_push_trigger ON public.messages;
CREATE TRIGGER messages_push_trigger
AFTER INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.on_message_insert_push();