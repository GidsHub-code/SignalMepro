-- Extend push_subscriptions for native (FCM/APNs) tokens alongside Web Push.

ALTER TABLE public.push_subscriptions
  ADD COLUMN IF NOT EXISTS platform text NOT NULL DEFAULT 'web',
  ADD COLUMN IF NOT EXISTS device_token text;

ALTER TABLE public.push_subscriptions
  ALTER COLUMN p256dh DROP NOT NULL,
  ALTER COLUMN auth DROP NOT NULL;

ALTER TABLE public.push_subscriptions
  DROP CONSTRAINT IF EXISTS push_subscriptions_platform_check;

ALTER TABLE public.push_subscriptions
  ADD CONSTRAINT push_subscriptions_platform_check
  CHECK (platform IN ('web', 'android', 'ios'));

CREATE INDEX IF NOT EXISTS push_subscriptions_user_platform_idx
  ON public.push_subscriptions (user_id, platform);

CREATE UNIQUE INDEX IF NOT EXISTS push_subscriptions_device_token_uidx
  ON public.push_subscriptions (device_token)
  WHERE device_token IS NOT NULL;