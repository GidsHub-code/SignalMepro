-- Restrict chat-media reads to authenticated users to satisfy public-bucket linter
DROP POLICY IF EXISTS "chat-media public read" ON storage.objects;
CREATE POLICY "chat-media auth read" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'chat-media');
UPDATE storage.buckets SET public = false WHERE id = 'chat-media';

-- Switch is_agent helper to SECURITY INVOKER (profiles RLS already allows authenticated reads)
CREATE OR REPLACE FUNCTION public.is_agent(_uid UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY INVOKER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _uid AND role = 'agent');
$$;