# Capacitor Native Wrap — Migration Plan

Goal: ship real Android + iOS apps that load the same TanStack web app, but use **native FCM/APNs** for push (works app-killed, phone-locked, high-priority), while keeping the existing PWA + Web Push paths intact for desktop/web users.

## Phase 1 — Project setup (in this Lovable repo)

1. Add Capacitor deps: `@capacitor/core`, `@capacitor/cli`, `@capacitor/android`, `@capacitor/ios`, `@capacitor/push-notifications`, `@capacitor/app`, `@capacitor/device`, `@capacitor/preferences`.
2. Create `capacitor.config.ts` with `appId: app.signalme`, `appName: SignalMe`, `webDir: dist`, and `server.url` set to the **published** Lovable URL so the native shell loads the live web app (no need to rebuild native binary on every web change).
3. Add a `src/lib/native.ts` helper that:
   - detects platform via `Capacitor.getPlatform()` (`web` | `android` | `ios`),
   - on web → calls existing `registerPushForCurrentUser()` (Web Push),
   - on native → requests permission, registers with FCM/APNs via `PushNotifications.register()`, and stores the **native device token + platform** in Supabase.
4. Wire `App.addListener('appUrlOpen', …)` so notification taps deep-link to `/chats/$id` etc.

## Phase 2 — Database changes (one migration)

Extend `push_subscriptions` to support both web and native tokens:

- add `platform text not null default 'web'` (`web` | `android` | `ios`)
- add `device_token text` (FCM/APNs token; nullable — web rows still use `endpoint`/`p256dh`/`auth`)
- make `endpoint`, `p256dh`, `auth` nullable
- unique constraint on `(user_id, device_token)` for native, keep existing on `endpoint` for web
- RLS unchanged (user manages own rows)

## Phase 3 — Push sender rewrite

The current `send-push` edge function only does Web Push. Refactor it to fan out per platform:

- **web rows** → existing `web-push` library path (no change)
- **android rows** → FCM HTTP v1 API (`https://fcm.googleapis.com/v1/projects/<id>/messages:send`) using a service-account JWT generated inside the function
- **ios rows** → APNs HTTP/2 with token-based auth (`.p8` key + key id + team id)

Add per-message `priority: high`, `content-available: 1` (iOS), and an `android` channel id. Dedup via a `notification_id` claim so iOS+Android+Web for the same logical event don't double-fire.

## Phase 4 — Secrets you'll need to add

I'll request these via the secrets tool when we reach Phase 3:

- `FCM_SERVICE_ACCOUNT_JSON` — the full service-account JSON from Firebase
- `APNS_KEY_P8` — contents of the `AuthKey_XXXX.p8` file
- `APNS_KEY_ID` — 10-char key ID
- `APNS_TEAM_ID` — Apple Developer Team ID
- `APNS_BUNDLE_ID` — e.g. `app.signalme`

## Phase 5 — Native build (you do this on your machine)

Lovable's sandbox cannot run Xcode or Android Studio. After Phase 1–4 ship, you:

1. Clone the repo locally, `bun install`, `bun run build`.
2. `npx cap add android && npx cap add ios`.
3. Open Android Studio → drop in `google-services.json` from Firebase → build APK / AAB → upload to Play Console.
4. Open Xcode → set bundle id, signing team, push capability → drop in `GoogleService-Info.plist` (optional) → archive → upload to App Store Connect.

I'll provide a `NATIVE_BUILD.md` walkthrough with exact steps.

## What needs your decision before I start

1. **App identifier / bundle id** — proposing `app.signalme`. OK?
2. **Voice/video calls** — your current code only has chat. Native CallKit (iOS) + ConnectionService (Android) full-screen call UI is **a separate, much larger scope** (WebRTC + signaling + native plugins). I'd recommend shipping chat push first, then doing calls in a second phase. Agree?
3. **Live reload vs bundled assets** — load from your published `lovable.app` URL (instant updates, needs internet to launch) or bundle the built assets into the binary (works offline-launch, but every web change needs a new app store release)? Recommending **published URL** for fast iteration.

Reply with answers to those 3 and I'll start Phase 1.
