import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "app.signalme",
  appName: "SignalMe",
  webDir: "dist",
  // Live-reload from the published Lovable URL so we don't need to ship a new
  // native binary every time the web app updates. Once you publish in Lovable,
  // this URL serves the latest production build.
  server: {
    url: "https://project--76fd10d7-8d15-4381-ad50-573b98d15b56.lovable.app",
    cleartext: false,
    androidScheme: "https",
  },
  android: {
    allowMixedContent: false,
  },
  plugins: {
    PushNotifications: {
      presentationOptions: ["badge", "sound", "alert"],
    },
  },
};

export default config;
